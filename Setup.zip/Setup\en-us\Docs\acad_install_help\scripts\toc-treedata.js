var tocIcons = ["topic"];var tocItemsFullName ="Installation Overview and FAQ";
var tocItemsDefaultTopic ="./files/topichead_0.htm";
var tocItems = [{
id: "d30e964"
,ttl: "Autodesk Installation and FAQ"
,ln: "./files/topichead_0.htm"
,ic: 0
,children: [{
id: "d30e18"
,ttl: "Introduction to Product Installation"
,ln: "./files/empty_concept_1.htm"
,ic: 0
,children: [{
id: "d30e968"
,ttl: "Introduction to Product Installation"
,ln: "./files/GUID-C91D0237-9A28-431E-9538-D8ACD4C69B48.htm"
,ic: 0
},
{
id: "d30e1639"
,ttl: "Frequently Asked Questions about Installation"
,ln: "./files/GUID-A33FC990-A783-4AC7-A771-12FD8C004AFF.htm"
,ic: 0
,children: [{
id: "d30e1667"
,ttl: "FAQ: What if I have lost my serial number or product key?"
,ln: "./files/GUID-CB1AEAA1-11D7-4B3A-A970-29B1A992A939.htm"
,ic: 0
},
{
id: "d30e1693"
,ttl: "FAQ: Why do I need to activate a product after installation?"
,ln: "./files/GUID-360452A1-CDDA-4F24-B3A3-1BC4160A27F4.htm"
,ic: 0
},
{
id: "d30e1716"
,ttl: "FAQ: Can I install Autodesk products from a website?"
,ln: "./files/GUID-96A9D9E1-DF28-4344-84A5-E042D8A3BDCF.htm"
,ic: 0
},
{
id: "d30e1753"
,ttl: "FAQ: How does a trial license work in a product suite or bundle?"
,ln: "./files/GUID-722747A9-A3DF-4D51-B18A-D59F615E04CB.htm"
,ic: 0
},
{
id: "d30e1782"
,ttl: "FAQ: How do I change my license type?"
,ln: "./files/GUID-66D6A541-197D-4AEB-B3FA-C7CD5924C51D.htm"
,ic: 0
},
{
id: "d30e1811"
,ttl: "FAQ: Where can I find product license information after installation?"
,ln: "./files/GUID-A1C8A7C8-EFD9-4CFD-B3D5-9777E5B0887D.htm"
,ic: 0
},
{
id: "d30e1847"
,ttl: "FAQ: After installation, how can I change product configuration, repair, or uninstall the product?"
,ln: "./files/GUID-78A2BAF7-CF56-48DE-B437-7D07147EA84F.htm"
,ic: 0
}
]}
]},
{
id: "d30e33"
,ttl: "About New Features for the 2015 Installation Guide"
,ln: "./files/empty_concept_2.htm"
,ic: 0
,children: [{
id: "d30e1005"
,ttl: "About New Features for the 2015 Installation Guide"
,ln: "./files/GUID-472E483D-72CB-4978-9DF6-DDEA0515B272.htm"
,ic: 0
}
]},
{
id: "d30e39"
,ttl: "About Preparing for Installation"
,ln: "./files/empty_concept_3.htm"
,ic: 0
,children: [{
id: "d30e1052"
,ttl: "About Preparing for Installation"
,ln: "./files/GUID-7844154D-C160-4EBF-B779-CEE629DAD963.htm"
,ic: 0
}
]},
{
id: "d30e45"
,ttl: "About Installation Types"
,ln: "./files/empty_concept_4.htm"
,ic: 0
,children: [{
id: "d30e1177"
,ttl: "About Installation Types"
,ln: "./files/GUID-68388F17-51BC-47E3-886F-3009169785B3.htm"
,ic: 0
}
]},
{
id: "d30e51"
,ttl: "About Product Language Selection"
,ln: "./files/empty_concept_5.htm"
,ic: 0
,children: [{
id: "d30e1250"
,ttl: "About Product Language Selection"
,ln: "./files/GUID-EED8A3B3-412A-4A25-BC61-1A838FDEDF95.htm"
,ic: 0
}
]},
{
id: "d30e56"
,ttl: "About License Types"
,ln: "./files/empty_concept_6.htm"
,ic: 0
,children: [{
id: "d30e1322"
,ttl: "About License Types"
,ln: "./files/GUID-DA9DA95D-461B-4BF9-9B32-2633DA333DB8.htm"
,ic: 0
}
]},
{
id: "d30e62"
,ttl: "About the Installation Path and Product Configuration"
,ln: "./files/empty_concept_7.htm"
,ic: 0
,children: [{
id: "d30e1437"
,ttl: "About the Installation Path and Product Configuration"
,ln: "./files/GUID-041E037E-31AA-45BB-8034-F266B8DA990B.htm"
,ic: 0
}
]},
{
id: "d30e68"
,ttl: "About Product Activation"
,ln: "./files/empty_concept_8.htm"
,ic: 0
,children: [{
id: "d30e1506"
,ttl: "About Product Activation"
,ln: "./files/GUID-2014E104-35AA-4EA7-87F1-68C9E07E6670.htm"
,ic: 0
}
]},
{
id: "d30e74"
,ttl: "About Deployments"
,ln: "./files/empty_concept_9.htm"
,ic: 0
,children: [{
id: "d30e1549"
,ttl: "About Deployments"
,ln: "./files/GUID-00D91EA4-940C-450E-AD33-9445E48A4A17.htm"
,ic: 0
}
]}
]},
{
id: "d30e1921"
,ttl: "Autodesk Network Administrator\'s Guide"
,ln: "./files/topichead_1.htm"
,ic: 0
,children: [{
id: "d30e1925"
,ttl: "Introduction to Network Administration"
,ln: "./files/GUID-AAB04133-AF72-44FD-8197-5919A3BB49C9.htm"
,ic: 0
,children: [{
id: "d30e1946"
,ttl: "Network Deployment"
,ln: "./files/GUID-3F604C34-6A58-4E84-BB15-38651CFB302F.htm"
,ic: 0
,children: [{
id: "d30e1969"
,ttl: "About New Features for the 2015 Network Administrator\'s Guide"
,ln: "./files/GUID-41E0D5DE-B310-4A77-9254-9E8E597432DB.htm"
,ic: 0
},
{
id: "d30e117"
,ttl: "About Deployments"
,ln: "./files/empty_concept_10.htm"
,ic: 0
,children: [{
id: "d30e2027"
,ttl: "About Deployments"
,ln: "./files/GUID-15AE1D9C-F8F1-4DB7-B17E-B68409A5A7C4.htm"
,ic: 0
},
{
id: "d30e3026"
,ttl: "Network Administration Glossary"
,ln: "./files/GUID-7A66FF23-92FA-4F90-8B52-5AF9DD6F3BDA.htm"
,ic: 0
}
]},
{
id: "d30e131"
,ttl: "About Language Pack Deployment"
,ln: "./files/empty_concept_11.htm"
,ic: 0
,children: [{
id: "d30e2108"
,ttl: "About Language Pack Deployment"
,ln: "./files/GUID-F464B79E-BE26-4441-8DD0-F021A256C3B1.htm"
,ic: 0
}
]},
{
id: "d30e136"
,ttl: "To Check Deployment Readiness"
,ln: "./files/empty_concept_12.htm"
,ic: 0
,children: [{
id: "d30e2136"
,ttl: "To Check Deployment Readiness"
,ln: "./files/GUID-1467D90C-9688-484C-9AC4-4B6A8C3C549E.htm"
,ic: 0
}
]},
{
id: "d30e151"
,ttl: "About .NET 3.5 Support for Windows 8/8.1"
,ln: "./files/empty_concept_13.htm"
,ic: 0
,children: [{
id: "d30e2190"
,ttl: "About .NET 3.5 Support for Windows 8/8.1"
,ln: "./files/GUID-DB69150E-BAE5-43D3-9FF4-CEEE4869206A.htm"
,ic: 0
}
]},
{
id: "d30e156"
,ttl: "About Installation Type"
,ln: "./files/empty_concept_14.htm"
,ic: 0
,children: [{
id: "d30e2262"
,ttl: "About Installation Type"
,ln: "./files/GUID-361AAD5C-D377-453D-A356-7F7249BC8327.htm"
,ic: 0
}
]},
{
id: "d30e162"
,ttl: "About the License Server Model"
,ln: "./files/empty_concept_15.htm"
,ic: 0
,children: [{
id: "d30e2336"
,ttl: "About the License Server Model"
,ln: "./files/GUID-9488E5B5-7925-455D-A846-3432942FAE4D.htm"
,ic: 0
}
]},
{
id: "d30e168"
,ttl: "About Product Configuration"
,ln: "./files/empty_concept_16.htm"
,ic: 0
,children: [{
id: "d30e2398"
,ttl: "About Product Configuration"
,ln: "./files/GUID-9F6E3341-7108-46CE-B15B-ED08889FD62F.htm"
,ic: 0
}
]},
{
id: "d30e175"
,ttl: "About Shared Components"
,ln: "./files/empty_concept_17.htm"
,ic: 0
,children: [{
id: "d30e2451"
,ttl: "About Shared Components"
,ln: "./files/GUID-3119F0E8-1247-4662-A393-C4E2A8C188EF.htm"
,ic: 0
}
]},
{
id: "d30e180"
,ttl: "About Including Additional Software"
,ln: "./files/empty_concept_18.htm"
,ic: 0
,children: [{
id: "d30e2485"
,ttl: "About Including Additional Software"
,ln: "./files/GUID-87A444ED-9C6F-42E5-BC17-0C95B0FE5723.htm"
,ic: 0
}
]},
{
id: "d30e186"
,ttl: "To Include Additional Software in a Deployment"
,ln: "./files/empty_concept_19.htm"
,ic: 0
,children: [{
id: "d30e2511"
,ttl: "To Include Additional Software in a Deployment"
,ln: "./files/GUID-207BB2C4-27CC-4EBA-9577-C7C4C2E0DB5A.htm"
,ic: 0
}
]},
{
id: "d30e192"
,ttl: "About Including Service Packs"
,ln: "./files/empty_concept_20.htm"
,ic: 0
,children: [{
id: "d30e2549"
,ttl: "About Including Service Packs"
,ln: "./files/GUID-3A6CAAC5-8C98-4C08-B98F-C9B63BFBF213.htm"
,ic: 0
}
]},
{
id: "d30e200"
,ttl: "To Work with Service Packs in Deployments"
,ln: "./files/empty_concept_21.htm"
,ic: 0
,children: [{
id: "d30e2595"
,ttl: "To Work with Service Packs in Deployments"
,ln: "./files/GUID-3BE6175C-A0F5-4B54-A9A9-1365ECEB0C1C.htm"
,ic: 0
}
]},
{
id: "d30e207"
,ttl: "About Network Shares"
,ln: "./files/empty_concept_22.htm"
,ic: 0
,children: [{
id: "d30e2678"
,ttl: "About Network Shares"
,ln: "./files/GUID-7AA9CD42-C0A1-4769-8DF1-D651F4A4F4D8.htm"
,ic: 0
}
]},
{
id: "d30e212"
,ttl: "To Create a Deployment"
,ln: "./files/empty_concept_23.htm"
,ic: 0
,children: [{
id: "d30e2720"
,ttl: "To Create a Deployment"
,ln: "./files/GUID-F46A4A5C-51F8-49AA-BF53-EBF2FDA532B9.htm"
,ic: 0
}
]},
{
id: "d30e219"
,ttl: "To Create a Combined 32- and 64-bit Deployment"
,ln: "./files/empty_concept_24.htm"
,ic: 0
,children: [{
id: "d30e2841"
,ttl: "To Create a Combined 32- and 64-bit Deployment"
,ln: "./files/GUID-02E5FAA2-C1C1-44E2-BD10-CC392F7FFDA9.htm"
,ic: 0
}
]},
{
id: "d30e225"
,ttl: "About Modifying a Deployment"
,ln: "./files/empty_concept_25.htm"
,ic: 0
,children: [{
id: "d30e2880"
,ttl: "About Modifying a Deployment"
,ln: "./files/GUID-AE8E0558-C5B8-4426-8CBE-C860CB9CB42E.htm"
,ic: 0
}
]},
{
id: "d30e230"
,ttl: "To Modify a Deployment"
,ln: "./files/empty_concept_26.htm"
,ic: 0
,children: [{
id: "d30e2918"
,ttl: "To Modify a Deployment"
,ln: "./files/GUID-69EB1F7D-A289-4E26-AE1E-34B435C9E674.htm"
,ic: 0
}
]},
{
id: "d30e237"
,ttl: "About the Administrative Image"
,ln: "./files/empty_concept_27.htm"
,ic: 0
,children: [{
id: "d30e2958"
,ttl: "About the Administrative Image"
,ln: "./files/GUID-421A2AF0-2C6F-4055-B745-ED9D3FDC644C.htm"
,ic: 0
}
]},
{
id: "d30e244"
,ttl: "About Uninstalling Products"
,ln: "./files/empty_concept_28.htm"
,ic: 0
,children: [{
id: "d30e2983"
,ttl: "About Uninstalling Products"
,ln: "./files/GUID-411152B0-096D-457A-94F0-0EE939985D9F.htm"
,ic: 0
}
]}
]},
{
id: "d30e3150"
,ttl: "Alternative Product Distribution Methods"
,ln: "./files/GUID-F3B718E3-0172-4243-9DE2-4A86576661CA.htm"
,ic: 0
,children: [{
id: "d30e3184"
,ttl: "About Batch Files for Deployments"
,ln: "./files/GUID-94AAAD23-FA9E-4584-A951-87171AA4EDA0.htm"
,ic: 0
,children: [{
id: "d30e265"
,ttl: "Sample Batch Files"
,ln: "./files/empty_concept_29.htm"
,ic: 0
,children: [{
id: "d30e3239"
,ttl: "Sample Batch Files"
,ln: "./files/GUID-E6B5B8C0-C2FF-41EB-B527-58D14CE3AE36.htm"
,ic: 0
}
]},
{
id: "d30e270"
,ttl: "To Run a Batch File"
,ln: "./files/empty_concept_30.htm"
,ic: 0
,children: [{
id: "d30e3376"
,ttl: "To Run a Batch File"
,ln: "./files/GUID-093374C4-F845-46B7-8B0D-CCB16C6E79D6.htm"
,ic: 0
}
]}
]},
{
id: "d30e3418"
,ttl: "About Microsoft SCCM for Deployments"
,ln: "./files/GUID-F9A14A04-FCA6-4ED8-B2E2-A495E3166B62.htm"
,ic: 0
,children: [{
id: "d30e275"
,ttl: "To Test a Deployment"
,ln: "./files/empty_concept_31.htm"
,ic: 0
,children: [{
id: "d30e3497"
,ttl: "To Test a Deployment"
,ln: "./files/GUID-1FA5E50E-52DB-4925-ACCE-04B8B1070581.htm"
,ic: 0
}
]},
{
id: "d30e283"
,ttl: "To Create an SCCM Software Installation Package"
,ln: "./files/empty_concept_32.htm"
,ic: 0
,children: [{
id: "d30e3526"
,ttl: "To Create an SCCM Software Installation Package"
,ln: "./files/GUID-E92C18C6-D7C9-4D6B-BFC8-B59B04F19C7C.htm"
,ic: 0
}
]},
{
id: "d30e289"
,ttl: "To Use SCCM to Uninstall Deployed Products"
,ln: "./files/empty_concept_33.htm"
,ic: 0
,children: [{
id: "d30e3694"
,ttl: "To Use SCCM to Uninstall Deployed Products"
,ln: "./files/GUID-CECF56AA-5A0A-4AA9-ACD4-14297F12C1CD.htm"
,ic: 0
}
]}
]},
{
id: "d30e3836"
,ttl: "About Imaging Software for Deployments"
,ln: "./files/GUID-0DF6CC38-BD26-4D0D-85D9-4E5A8237CA11.htm"
,ic: 0
,children: [{
id: "d30e294"
,ttl: "To Use Imaging Software to Distribute Multi-Seat Stand-Alone Products"
,ln: "./files/empty_concept_34.htm"
,ic: 0
,children: [{
id: "d30e3898"
,ttl: "To Use Imaging Software to Distribute Multi-Seat Stand-Alone Products"
,ln: "./files/GUID-3E2FD804-3E96-454D-8449-01A790CEF698.htm"
,ic: 0
}
]},
{
id: "d30e300"
,ttl: "To Use Imaging Software to Distribute Network Licensed Products"
,ln: "./files/empty_concept_35.htm"
,ic: 0
,children: [{
id: "d30e3935"
,ttl: "To Use Imaging Software to Distribute Network Licensed Products"
,ln: "./files/GUID-ACD6AEE4-E7EC-487C-BBE9-83CFD84222A9.htm"
,ic: 0
}
]},
{
id: "d30e306"
,ttl: "To Restore a Master Image"
,ln: "./files/empty_concept_36.htm"
,ic: 0
,children: [{
id: "d30e3972"
,ttl: "To Restore a Master Image"
,ln: "./files/GUID-76907682-F502-4194-89E1-8E36AA37BEAF.htm"
,ic: 0
}
]},
{
id: "d30e312"
,ttl: "To Clean a Master System and Restore the Operating System"
,ln: "./files/empty_concept_37.htm"
,ic: 0
,children: [{
id: "d30e4037"
,ttl: "To Clean a Master System and Restore the Operating System"
,ln: "./files/GUID-6BBAB9AB-EE48-4230-B5EF-6DD2DF32F8C3.htm"
,ic: 0
}
]}
]}
]},
{
id: "d30e4087"
,ttl: "Frequently Asked Questions about Deployments"
,ln: "./files/GUID-839ABCB6-25D6-41FB-9B31-8E501F5DB253.htm"
,ic: 0
,children: [{
id: "d30e333"
,ttl: "FAQ: Where should deployments be located?"
,ln: "./files/empty_concept_38.htm"
,ic: 0
,children: [{
id: "d30e4124"
,ttl: "FAQ: Where should deployments be located?"
,ln: "./files/GUID-015C7713-F38E-4D0B-9687-945BC283EDF1.htm"
,ic: 0
}
]},
{
id: "d30e341"
,ttl: "FAQ: When should I select all products for the administrative image, and can I add products later?"
,ln: "./files/empty_concept_39.htm"
,ic: 0
,children: [{
id: "d30e4164"
,ttl: "FAQ: When should I select all products for the administrative image, and can I add products later?"
,ln: "./files/GUID-C00D3641-8D78-49FB-9F11-CBD73570ECEB.htm"
,ic: 0
}
]},
{
id: "d30e348"
,ttl: "FAQ: What are profiles of user preferences?"
,ln: "./files/empty_concept_40.htm"
,ic: 0
,children: [{
id: "d30e4195"
,ttl: "FAQ: What are profiles of user preferences?"
,ln: "./files/GUID-F5DAE4D6-4662-4B1F-B940-D5FF3125754D.htm"
,ic: 0
}
]},
{
id: "d30e354"
,ttl: "FAQ: Where can I check for available service packs?"
,ln: "./files/empty_concept_41.htm"
,ic: 0
,children: [{
id: "d30e4226"
,ttl: "FAQ: Where can I check for available service packs?"
,ln: "./files/GUID-90C580F3-E62C-4897-9BB0-F44D68E9E8FD.htm"
,ic: 0
}
]},
{
id: "d30e360"
,ttl: "FAQ: How do I extract an MSP file?"
,ln: "./files/empty_concept_42.htm"
,ic: 0
,children: [{
id: "d30e4252"
,ttl: "FAQ: How do I extract an MSP file?"
,ln: "./files/GUID-71929253-E183-444E-9A98-B079B9AA34B4.htm"
,ic: 0
}
]},
{
id: "d30e4289"
,ttl: "FAQ: How should I configure a network license server for a firewall?"
,ln: "./files/GUID-0CC0048C-7110-400A-8B5F-214DECFF9102.htm"
,ic: 0
},
{
id: "d30e366"
,ttl: "FAQ: How can I see what is included in a default installation?"
,ln: "./files/empty_concept_43.htm"
,ic: 0
,children: [{
id: "d30e4322"
,ttl: "FAQ: How can I see what is included in a default installation?"
,ln: "./files/GUID-655F5E3F-D86E-47FA-B4DB-6ECD14F209D9.htm"
,ic: 0
}
]},
{
id: "d30e4349"
,ttl: "FAQ: Can I change the installation folder when adding or removing features?"
,ln: "./files/GUID-F7C7AAD1-2B0F-41DB-996A-28433A5B760A.htm"
,ic: 0
},
{
id: "d30e4373"
,ttl: "FAQ: How do I install tools and utilities after installing my product?"
,ln: "./files/GUID-D8651D28-733A-47A3-8F93-B6ABBE4A15F6.htm"
,ic: 0
},
{
id: "d30e371"
,ttl: "FAQ: When should I reinstall the product instead of repairing it?"
,ln: "./files/empty_concept_44.htm"
,ic: 0
,children: [{
id: "d30e4398"
,ttl: "FAQ: When should I reinstall the product instead of repairing it?"
,ln: "./files/GUID-A7DCEB7A-8FCC-49F3-A213-F3B675BB4DFC.htm"
,ic: 0
}
]},
{
id: "d30e377"
,ttl: "FAQ: Do I need the original media to reinstall my product?"
,ln: "./files/empty_concept_45.htm"
,ic: 0
,children: [{
id: "d30e4423"
,ttl: "FAQ: Do I need the original media to reinstall my product?"
,ln: "./files/GUID-CFA6A80B-7342-46C0-BFC6-7AA7EF591A50.htm"
,ic: 0
}
]},
{
id: "d30e382"
,ttl: "FAQ: When I uninstall a product, what files are left on my system?"
,ln: "./files/empty_concept_46.htm"
,ic: 0
,children: [{
id: "d30e4452"
,ttl: "FAQ: When I uninstall a product, what files are left on my system?"
,ln: "./files/GUID-45B01092-CDBF-4096-8B65-5A2BAE68EA84.htm"
,ic: 0
}
]}
]}
]}
]},
{
id: "d30e4605"
,ttl: "Autodesk Licensing Guide"
,ln: "./files/topichead_2.htm"
,ic: 0
,children: [{
id: "d30e4609"
,ttl: "Introduction"
,ln: "./files/topichead_3.htm"
,ic: 0
,children: [{
id: "d30e401"
,ttl: "Licensing Overview"
,ln: "./files/empty_concept_47.htm"
,ic: 0
,children: [{
id: "d30e4613"
,ttl: "Licensing Overview"
,ln: "./files/GUID-10F8D03C-A0E0-4055-A485-566D57085AF0.htm"
,ic: 0
}
]},
{
id: "d30e4640"
,ttl: "About New Features for the 2015 Licensing Guide"
,ln: "./files/GUID-2A403388-F44E-48E3-B7E7-F03498B6245B.htm"
,ic: 0
},
{
id: "d30e409"
,ttl: "About License Types"
,ln: "./files/empty_concept_48.htm"
,ic: 0
,children: [{
id: "d30e4832"
,ttl: "About License Types"
,ln: "./files/GUID-83BEF89C-1AC2-4C10-B977-2DCFF2C745E6.htm"
,ic: 0
}
]},
{
id: "d30e419"
,ttl: "About License Activation and Registration"
,ln: "./files/empty_concept_49.htm"
,ic: 0
,children: [{
id: "d30e5020"
,ttl: "About License Activation and Registration"
,ln: "./files/GUID-9609CA5D-0A6D-46DF-984C-BE4A602DA5F7.htm"
,ic: 0
}
]},
{
id: "d30e427"
,ttl: "About Simplified Licensing"
,ln: "./files/empty_concept_50.htm"
,ic: 0
,children: [{
id: "d30e5086"
,ttl: "About Simplified Licensing"
,ln: "./files/GUID-14BEFBED-4019-428F-B014-9EABFFE57B08.htm"
,ic: 0
}
]},
{
id: "d30e5120"
,ttl: "Licensing Glossary"
,ln: "./files/GUID-B1D98363-DB19-4270-9AE9-081736630568.htm"
,ic: 0
}
]},
{
id: "d30e5433"
,ttl: "Stand-Alone Licensing"
,ln: "./files/topichead_4.htm"
,ic: 0
,children: [{
id: "d30e450"
,ttl: "About Stand-Alone Licenses"
,ln: "./files/empty_concept_51.htm"
,ic: 0
,children: [{
id: "d30e5437"
,ttl: "About Stand-Alone Licenses"
,ln: "./files/GUID-10165C61-8741-4D5E-A752-A7B4327B49E5.htm"
,ic: 0
}
]},
{
id: "d30e457"
,ttl: "To View Product License Information"
,ln: "./files/empty_concept_52.htm"
,ic: 0
,children: [{
id: "d30e5527"
,ttl: "To View Product License Information"
,ln: "./files/GUID-3CAD2766-2DEF-4E05-BDCA-7C59148403BD.htm"
,ic: 0
}
]},
{
id: "d30e464"
,ttl: "To Save License Information as a Text File"
,ln: "./files/empty_concept_53.htm"
,ic: 0
,children: [{
id: "d30e5570"
,ttl: "To Save License Information as a Text File"
,ln: "./files/GUID-E8D4E89C-BA67-45BB-BF01-AFB3802C890B.htm"
,ic: 0
}
]},
{
id: "d30e471"
,ttl: "To Update a Serial Number"
,ln: "./files/empty_concept_54.htm"
,ic: 0
,children: [{
id: "d30e5611"
,ttl: "To Update a Serial Number"
,ln: "./files/GUID-A465C7CC-613B-4F39-859B-883E4421702D.htm"
,ic: 0
}
]},
{
id: "d30e478"
,ttl: "About Term Licenses"
,ln: "./files/empty_concept_55.htm"
,ic: 0
,children: [{
id: "d30e5681"
,ttl: "About Term Licenses"
,ln: "./files/GUID-EEB69518-3F54-4CB2-B721-EF255E3D8878.htm"
,ic: 0
}
]},
{
id: "d30e485"
,ttl: "About Transferring Stand-Alone Licenses"
,ln: "./files/empty_concept_56.htm"
,ic: 0
,children: [{
id: "d30e5712"
,ttl: "About Transferring Stand-Alone Licenses"
,ln: "./files/GUID-0C62C666-2514-4A27-BC37-5EFCB0FF001C.htm"
,ic: 0
}
]},
{
id: "d30e492"
,ttl: "To Export a License"
,ln: "./files/empty_concept_57.htm"
,ic: 0
,children: [{
id: "d30e5783"
,ttl: "To Export a License"
,ln: "./files/GUID-7681FACA-CEB8-4E0C-887E-629695BBAE9D.htm"
,ic: 0
}
]},
{
id: "d30e498"
,ttl: "To Import a License"
,ln: "./files/empty_concept_58.htm"
,ic: 0
,children: [{
id: "d30e5919"
,ttl: "To Import a License"
,ln: "./files/GUID-65785EE1-8C10-40D7-AA30-A10ADC1CABB8.htm"
,ic: 0
}
]},
{
id: "d30e504"
,ttl: "About Preventing Stand-Alone License Errors"
,ln: "./files/empty_concept_59.htm"
,ic: 0
,children: [{
id: "d30e6035"
,ttl: "About Preventing Stand-Alone License Errors"
,ln: "./files/GUID-E6112E4F-E91E-4B6E-B20F-E6DF29036157.htm"
,ic: 0
,children: [{
id: "d30e515"
,ttl: "About Preserving a License When Hardware Changes"
,ln: "./files/empty_concept_60.htm"
,ic: 0
,children: [{
id: "d30e6060"
,ttl: "About Preserving a License When Hardware Changes"
,ln: "./files/GUID-07FD3499-244E-4E5C-8D16-9B3B30C06E2A.htm"
,ic: 0
}
]},
{
id: "d30e520"
,ttl: "To Preserve a License When Reinstalling an Operating System"
,ln: "./files/empty_concept_61.htm"
,ic: 0
,children: [{
id: "d30e6097"
,ttl: "To Preserve a License When Reinstalling an Operating System"
,ln: "./files/GUID-06973B07-88F6-4FA6-955E-200522D9229A.htm"
,ic: 0
}
]},
{
id: "d30e526"
,ttl: "About System Date and Time License Errors"
,ln: "./files/empty_concept_62.htm"
,ic: 0
,children: [{
id: "d30e6155"
,ttl: "About System Date and Time License Errors"
,ln: "./files/GUID-C2542B2C-F003-452D-A934-23DFCF13470A.htm"
,ic: 0
}
]},
{
id: "d30e531"
,ttl: "About Preserving a License When Distributing Products"
,ln: "./files/empty_concept_63.htm"
,ic: 0
,children: [{
id: "d30e6186"
,ttl: "About Preserving a License When Distributing Products"
,ln: "./files/GUID-762C7280-2E9C-4CAA-8C34-1D515DAF02EB.htm"
,ic: 0
}
]},
{
id: "d30e537"
,ttl: "About Preserving a License on a Re-imaged Computer"
,ln: "./files/empty_concept_64.htm"
,ic: 0
,children: [{
id: "d30e6224"
,ttl: "About Preserving a License on a Re-imaged Computer"
,ln: "./files/GUID-87149F45-C8AB-461C-A9D7-31D1246CEA70.htm"
,ic: 0
}
]},
{
id: "d30e543"
,ttl: "About Restoring Access to a Term License"
,ln: "./files/empty_concept_65.htm"
,ic: 0
,children: [{
id: "d30e6255"
,ttl: "About Restoring Access to a Term License"
,ln: "./files/GUID-2CB25F16-B05F-4AD5-83EF-9F87D389841A.htm"
,ic: 0
}
]}
]}
]}
]},
{
id: "d30e6283"
,ttl: "Network Licensing"
,ln: "./files/topichead_5.htm"
,ic: 0
,children: [{
id: "d30e577"
,ttl: "About Network License Management"
,ln: "./files/empty_concept_67.htm"
,ic: 0
,children: [{
id: "d30e6287"
,ttl: "About Network License Management"
,ln: "./files/GUID-32255831-B9CC-4E86-8E99-86910DB3D41E.htm"
,ic: 0
}
]},
{
id: "d30e569"
,ttl: "About Network Licensing and Server Models"
,ln: "./files/empty_concept_66.htm"
,ic: 0
,children: [{
id: "d30e6372"
,ttl: "About Network Licensing and Server Models"
,ln: "./files/GUID-20C53262-660D-4BA1-83C5-418D48227A0D.htm"
,ic: 0
,children: [{
id: "d30e6392"
,ttl: "About the Single License Server Model"
,ln: "./files/GUID-3B21574D-A3E1-4165-BDA9-C14064BAEC5A.htm"
,ic: 0
},
{
id: "d30e6433"
,ttl: "About the Distributed License Server Model"
,ln: "./files/GUID-62202286-6159-471D-BC8E-EE8BBA1A6534.htm"
,ic: 0
},
{
id: "d30e6481"
,ttl: "About the Redundant License Server Model"
,ln: "./files/GUID-B1A6F0E2-D58F-4646-B9C7-4E9C4FA711C3.htm"
,ic: 0
}
]}
]},
{
id: "d30e588"
,ttl: "About License Sharing and Cascading"
,ln: "./files/empty_concept_68.htm"
,ic: 0
,children: [{
id: "d30e6527"
,ttl: "About License Sharing and Cascading"
,ln: "./files/GUID-007E5C65-5186-48F4-9C8A-57753BAEE250.htm"
,ic: 0
}
]},
{
id: "d30e594"
,ttl: "About Running Previous Versions of Products"
,ln: "./files/empty_concept_69.htm"
,ic: 0
,children: [{
id: "d30e6579"
,ttl: "About Running Previous Versions of Products"
,ln: "./files/GUID-339891A1-38FD-4B11-8481-ECD056F9D326.htm"
,ic: 0
}
]},
{
id: "d30e601"
,ttl: "About Losing Your Connection to the License Server"
,ln: "./files/empty_concept_70.htm"
,ic: 0
,children: [{
id: "d30e6625"
,ttl: "About Losing Your Connection to the License Server"
,ln: "./files/GUID-15FC76A1-2ECF-4728-A747-18A8A3E4614C.htm"
,ic: 0
}
]},
{
id: "d30e606"
,ttl: "Windows System Requirements for the Network License Manager"
,ln: "./files/empty_concept_71.htm"
,ic: 0
,children: [{
id: "d30e6656"
,ttl: "Windows System Requirements for the Network License Manager"
,ln: "./files/GUID-110E37F7-724F-4416-94EE-A74234AAA8CB.htm"
,ic: 0
}
]},
{
id: "d30e611"
,ttl: "Mac OS X System Requirements for the Network License Manager"
,ln: "./files/empty_concept_72.htm"
,ic: 0
,children: [{
id: "d30e6800"
,ttl: "Mac OS X System Requirements for the Network License Manager"
,ln: "./files/GUID-53EE23D5-0665-4C11-8150-49055E3A2788.htm"
,ic: 0
}
]},
{
id: "d30e616"
,ttl: "Linux System Requirements for the Network License Manager"
,ln: "./files/empty_concept_73.htm"
,ic: 0
,children: [{
id: "d30e6895"
,ttl: "Linux System Requirements for the Network License Manager"
,ln: "./files/GUID-2ECB565B-A0CC-4F83-9B84-D960641085B3.htm"
,ic: 0
}
]},
{
id: "d30e621"
,ttl: "License File Reference Guide"
,ln: "./files/empty_concept_74.htm"
,ic: 0
,children: [{
id: "d30e6998"
,ttl: "License File Reference Guide"
,ln: "./files/GUID-73D11DDF-14E3-4312-A2F4-3CD75E9ACD47.htm"
,ic: 0
,children: [{
id: "d30e7485"
,ttl: "Example of a License File for a Single or Distributed Server"
,ln: "./files/GUID-1FE6A15F-0373-4A6E-B704-288B532D7F98.htm"
,ic: 0
},
{
id: "d30e7521"
,ttl: "Example of a License File for a Redundant Server"
,ln: "./files/GUID-9E171B80-E98B-4231-8A20-C9F56C338CF0.htm"
,ic: 0
},
{
id: "d30e7562"
,ttl: "Example of a Combined License File"
,ln: "./files/GUID-AF6A64E0-CEF3-43EB-8C88-4C32227FE59B.htm"
,ic: 0
}
]}
]},
{
id: "d30e628"
,ttl: "About Package License Files"
,ln: "./files/empty_concept_75.htm"
,ic: 0
,children: [{
id: "d30e7605"
,ttl: "About Package License Files"
,ln: "./files/GUID-5D66A4C3-03CB-423D-933D-632D5E53C97E.htm"
,ic: 0
,children: [{
id: "d30e7643"
,ttl: "Example of a Package License File for a Single or Distributed Server"
,ln: "./files/GUID-C29030BB-9E5D-43BD-8439-EF9518C96D96.htm"
,ic: 0
},
{
id: "d30e7679"
,ttl: "Example of a Package License File for a Redundant Server"
,ln: "./files/GUID-831ED8FF-63FD-4C65-827B-BFE487531AD4.htm"
,ic: 0
},
{
id: "d30e7715"
,ttl: "Example of a Combined Package License File"
,ln: "./files/GUID-B3EBEC69-1FB1-4DAE-B1FD-52BC113D9722.htm"
,ic: 0
}
]}
]}
]},
{
id: "d30e7751"
,ttl: "Running Network License Manager"
,ln: "./files/topichead_6.htm"
,ic: 0
,children: [{
id: "d30e653"
,ttl: "About Installing the Network License Manager"
,ln: "./files/empty_concept_76.htm"
,ic: 0
,children: [{
id: "d30e7755"
,ttl: "About Installing the Network License Manager"
,ln: "./files/GUID-98D7AFDB-180E-4363-827F-177E6932253F.htm"
,ic: 0
}
]},
{
id: "d30e663"
,ttl: "To Install Network License Manager on a Windows Server"
,ln: "./files/empty_concept_77.htm"
,ic: 0
,children: [{
id: "d30e7816"
,ttl: "To Install Network License Manager on a Windows Server"
,ln: "./files/GUID-E22C32F2-E5AD-4F28-84BC-04C5702226E2.htm"
,ic: 0
}
]},
{
id: "d30e673"
,ttl: "To Install Network License Manager on a Mac OS X Server"
,ln: "./files/empty_concept_78.htm"
,ic: 0
,children: [{
id: "d30e7843"
,ttl: "To Install Network License Manager on a Mac OS X Server"
,ln: "./files/GUID-442B5579-A3F3-464E-9951-2EF517EB2F52.htm"
,ic: 0
}
]},
{
id: "d30e681"
,ttl: "To Install Network License Manager on a Linux Server"
,ln: "./files/empty_concept_79.htm"
,ic: 0
,children: [{
id: "d30e7893"
,ttl: "To Install Network License Manager on a Linux Server"
,ln: "./files/GUID-E0A0734A-4F19-4A36-A954-8FC5E77B6CF7.htm"
,ic: 0
}
]},
{
id: "d30e7924"
,ttl: "To Obtain a Host Name and ID at the Windows Command Prompt"
,ln: "./files/GUID-7F19CEBD-8971-4360-A0D5-0F8069BDBA92.htm"
,ic: 0
},
{
id: "d30e7971"
,ttl: "To Obtain a Host Name and ID Using LMTOOLS"
,ln: "./files/GUID-91C6B461-F5DB-4324-A3AA-F3B850B23FD8.htm"
,ic: 0
},
{
id: "d30e8019"
,ttl: "To Obtain a Host Name and ID at a Mac or Linux Terminal Window"
,ln: "./files/GUID-37DB91DD-1439-487F-8D7F-DF6774085F47.htm"
,ic: 0
},
{
id: "d30e689"
,ttl: "To Request a License File"
,ln: "./files/empty_concept_80.htm"
,ic: 0
,children: [{
id: "d30e8062"
,ttl: "To Request a License File"
,ln: "./files/GUID-1A5CCC42-0E4F-4C3A-BB99-3C807D8740CD.htm"
,ic: 0
}
]},
{
id: "d30e699"
,ttl: "About Combining Licenses"
,ln: "./files/empty_concept_81.htm"
,ic: 0
,children: [{
id: "d30e8147"
,ttl: "About Combining Licenses"
,ln: "./files/GUID-753DC243-57B6-439E-9B58-C00B87F4B356.htm"
,ic: 0
}
]},
{
id: "d30e707"
,ttl: "To Create a Combined License File"
,ln: "./files/empty_concept_82.htm"
,ic: 0
,children: [{
id: "d30e8204"
,ttl: "To Create a Combined License File"
,ln: "./files/GUID-44D693F1-193A-4A9B-BCC6-4228657BC0FE.htm"
,ic: 0
}
]},
{
id: "d30e719"
,ttl: "To Configure a Windows License Server"
,ln: "./files/empty_concept_83.htm"
,ic: 0
,children: [{
id: "d30e8248"
,ttl: "To Configure a Windows License Server"
,ln: "./files/GUID-CCA04D9D-98D3-4B6F-BB19-528074BBC721.htm"
,ic: 0
}
]},
{
id: "d30e726"
,ttl: "To Configure a Mac OS X License Server"
,ln: "./files/empty_concept_84.htm"
,ic: 0
,children: [{
id: "d30e8388"
,ttl: "To Configure a Mac OS X License Server"
,ln: "./files/GUID-63A266F1-BDE6-4178-A785-3B3026E0A3B6.htm"
,ic: 0
}
]},
{
id: "d30e733"
,ttl: "To Configure a Linux License Server"
,ln: "./files/empty_concept_85.htm"
,ic: 0
,children: [{
id: "d30e8531"
,ttl: "To Configure a Linux License Server"
,ln: "./files/GUID-C28A4DC6-2A36-4127-91A8-1426E03D8C68.htm"
,ic: 0
}
]},
{
id: "d30e740"
,ttl: "To Uninstall the Network License Manager on Windows"
,ln: "./files/empty_concept_86.htm"
,ic: 0
,children: [{
id: "d30e8653"
,ttl: "To Uninstall the Network License Manager on Windows"
,ln: "./files/GUID-AFD14346-AD51-492D-808C-792920FF347A.htm"
,ic: 0
}
]},
{
id: "d30e747"
,ttl: "To Uninstall the Network License Manager on a Mac OS X Server"
,ln: "./files/empty_concept_87.htm"
,ic: 0
,children: [{
id: "d30e8720"
,ttl: "To Uninstall the Network License Manager on a Mac OS X Server"
,ln: "./files/GUID-5066BBC5-293F-46D5-B772-EBAE768AF30D.htm"
,ic: 0
}
]},
{
id: "d30e753"
,ttl: "To Uninstall the Network License Manager on a Linux Server"
,ln: "./files/empty_concept_88.htm"
,ic: 0
,children: [{
id: "d30e8755"
,ttl: "To Uninstall the Network License Manager on a Linux Server"
,ln: "./files/GUID-8593EC5E-A2A0-49D2-ABFB-4BA704E4A5C1.htm"
,ic: 0
}
]}
]},
{
id: "d30e8794"
,ttl: "Configuring Network Licenses"
,ln: "./files/topichead_7.htm"
,ic: 0
,children: [{
id: "d30e779"
,ttl: "About FLEXnet Configuration Tools"
,ln: "./files/empty_concept_89.htm"
,ic: 0
,children: [{
id: "d30e8798"
,ttl: "About FLEXnet Configuration Tools"
,ln: "./files/GUID-A74767BC-AF4A-4CA7-A00F-65E0860FD5A2.htm"
,ic: 0
}
]},
{
id: "d30e788"
,ttl: "About Windows Utilities for License Server Management"
,ln: "./files/empty_concept_90.htm"
,ic: 0
,children: [{
id: "d30e8864"
,ttl: "About Windows Utilities for License Server Management"
,ln: "./files/GUID-51C2F43E-FD59-47B4-B031-D64D1BEDA006.htm"
,ic: 0
}
]},
{
id: "d30e795"
,ttl: "To Stop and Restart a Windows License Server"
,ln: "./files/empty_concept_91.htm"
,ic: 0
,children: [{
id: "d30e8945"
,ttl: "To Stop and Restart a Windows License Server"
,ln: "./files/GUID-D22029F3-9DD8-4A87-B808-9A79801AED4D.htm"
,ic: 0
}
]},
{
id: "d30e802"
,ttl: "To Stop and Restart a Mac OS X License Server"
,ln: "./files/empty_concept_92.htm"
,ic: 0
,children: [{
id: "d30e9070"
,ttl: "To Stop and Restart a Mac OS X License Server"
,ln: "./files/GUID-F8E86840-997C-41C6-8159-BC6C57016EE5.htm"
,ic: 0
}
]},
{
id: "d30e809"
,ttl: "To Stop and Restart a Linux License Server"
,ln: "./files/empty_concept_93.htm"
,ic: 0
,children: [{
id: "d30e9144"
,ttl: "To Stop and Restart a Linux License Server"
,ln: "./files/GUID-5F780F06-D5F2-4E36-B4B8-2D5B0048116D.htm"
,ic: 0
}
]},
{
id: "d30e816"
,ttl: "About Options Files for Network Licenses"
,ln: "./files/empty_concept_94.htm"
,ic: 0
,children: [{
id: "d30e9198"
,ttl: "About Options Files for Network Licenses"
,ln: "./files/GUID-A8F1F6EB-FC4B-4B90-85FD-2F58149B6B54.htm"
,ic: 0
}
]},
{
id: "d30e824"
,ttl: "To Create an Options File"
,ln: "./files/empty_concept_95.htm"
,ic: 0
,children: [{
id: "d30e9261"
,ttl: "To Create an Options File"
,ln: "./files/GUID-A035996D-03C0-4BD3-8242-8E6771EE3E80.htm"
,ic: 0
}
]},
{
id: "d30e834"
,ttl: "To Create a Report Log in the Options File"
,ln: "./files/empty_concept_96.htm"
,ic: 0
,children: [{
id: "d30e9390"
,ttl: "To Create a Report Log in the Options File"
,ln: "./files/GUID-512A8A29-2494-41F7-96A7-7EDE5BDA802D.htm"
,ic: 0
}
]},
{
id: "d30e841"
,ttl: "About License Borrowing"
,ln: "./files/empty_concept_97.htm"
,ic: 0
,children: [{
id: "d30e9449"
,ttl: "About License Borrowing"
,ln: "./files/GUID-62577AF9-0B23-4335-B670-C3BFC1FB73AE.htm"
,ic: 0
}
]},
{
id: "d30e849"
,ttl: "To Configure License Borrowing in the Options File"
,ln: "./files/empty_concept_98.htm"
,ic: 0
,children: [{
id: "d30e9513"
,ttl: "To Configure License Borrowing in the Options File"
,ln: "./files/GUID-1234F0C4-2BD2-4BAB-B0E2-ADD1385D1C2E.htm"
,ic: 0
}
]},
{
id: "d30e857"
,ttl: "To Borrow a License"
,ln: "./files/empty_concept_99.htm"
,ic: 0
,children: [{
id: "d30e9599"
,ttl: "To Borrow a License"
,ln: "./files/GUID-8E8EDE61-003E-4B7F-B3E7-8D980E409A74.htm"
,ic: 0
}
]},
{
id: "d30e864"
,ttl: "To Return a Borrowed License Early"
,ln: "./files/empty_concept_100.htm"
,ic: 0
,children: [{
id: "d30e9685"
,ttl: "To Return a Borrowed License Early"
,ln: "./files/GUID-E58F2A25-F8CD-400C-A497-A5823268FAC5.htm"
,ic: 0
}
]},
{
id: "d30e870"
,ttl: "About Network License Timeout"
,ln: "./files/empty_concept_101.htm"
,ic: 0
,children: [{
id: "d30e9759"
,ttl: "About Network License Timeout"
,ln: "./files/GUID-6687C6CD-FDC3-465E-8386-FE979523EBB6.htm"
,ic: 0
}
]},
{
id: "d30e875"
,ttl: "To Set License Timeout in the Options File"
,ln: "./files/empty_concept_102.htm"
,ic: 0
,children: [{
id: "d30e9792"
,ttl: "To Set License Timeout in the Options File"
,ln: "./files/GUID-D2E599C4-577E-4ABE-9987-B3B8654CDB4F.htm"
,ic: 0
}
]},
{
id: "d30e880"
,ttl: "About Updating FLEXnet from a Previous Version"
,ln: "./files/empty_concept_103.htm"
,ic: 0
,children: [{
id: "d30e9846"
,ttl: "About Updating FLEXnet from a Previous Version"
,ln: "./files/GUID-2FE4DC56-9AB7-4AA5-9AEB-DB3D92FA5F91.htm"
,ic: 0
}
]},
{
id: "d30e890"
,ttl: "To Update FLEXnet on a Windows License Server"
,ln: "./files/empty_concept_104.htm"
,ic: 0
,children: [{
id: "d30e9896"
,ttl: "To Update FLEXnet on a Windows License Server"
,ln: "./files/GUID-D7F38507-4516-419B-A71C-3A53332BF1D8.htm"
,ic: 0
}
]},
{
id: "d30e899"
,ttl: "To Update FLEXnet on a Mac OS X or Linux License Server"
,ln: "./files/empty_concept_105.htm"
,ic: 0
,children: [{
id: "d30e10073"
,ttl: "To Update FLEXnet on a Mac OS X or Linux License Server"
,ln: "./files/GUID-FB2F0C2E-E335-4DED-B2FB-AE8129752BDA.htm"
,ic: 0
}
]}
]},
{
id: "d30e10200"
,ttl: "Frequently Asked Questions about Network Licensing"
,ln: "./files/topichead_8.htm"
,ic: 0
,children: [{
id: "d30e916"
,ttl: "FAQ: What is the difference between a stand-alone and a network license?"
,ln: "./files/empty_concept_106.htm"
,ic: 0
,children: [{
id: "d30e10204"
,ttl: "FAQ: What is the difference between a stand-alone and a network license?"
,ln: "./files/GUID-CFB2242F-519D-4715-9AA9-A1BE3F3FED10.htm"
,ic: 0
}
]},
{
id: "d30e923"
,ttl: "FAQ: What is the benefit of network licensing?"
,ln: "./files/empty_concept_107.htm"
,ic: 0
,children: [{
id: "d30e10227"
,ttl: "FAQ: What is the benefit of network licensing?"
,ln: "./files/GUID-85E4C5F2-AE03-4E0C-88CE-64C80111566A.htm"
,ic: 0
}
]},
{
id: "d30e930"
,ttl: "FAQ: What is SAMreport-Lite?"
,ln: "./files/empty_concept_108.htm"
,ic: 0
,children: [{
id: "d30e10264"
,ttl: "FAQ: What is SAMreport-Lite?"
,ln: "./files/GUID-DFAB0611-FE7D-4D68-A765-7A146340351B.htm"
,ic: 0
}
]},
{
id: "d30e10292"
,ttl: "FAQ: How can I resolve a licensing error when starting a program?"
,ln: "./files/GUID-8B89BEC7-6CDF-4B44-A179-E7C54E536F84.htm"
,ic: 0
},
{
id: "d30e936"
,ttl: "FAQ: How does the licensing process use the Internet?"
,ln: "./files/empty_concept_109.htm"
,ic: 0
,children: [{
id: "d30e10333"
,ttl: "FAQ: How does the licensing process use the Internet?"
,ln: "./files/GUID-A32E1EFE-B580-4C4C-9688-5CA6925F015E.htm"
,ic: 0
}
]},
{
id: "d30e942"
,ttl: "FAQ: Can I use the Network License Manager with IPv6?"
,ln: "./files/empty_concept_110.htm"
,ic: 0
,children: [{
id: "d30e10360"
,ttl: "FAQ: Can I use the Network License Manager with IPv6?"
,ln: "./files/GUID-FFAA6C8D-A313-41EB-8E4E-3E150EB4FE0E.htm"
,ic: 0
}
]}
]}
]},
{
id: "d30e10399"
,ttl: "AutoCAD Installation Supplement"
,ln: "./files/topichead_9.htm"
,ic: 0
,children: [{
id: "d30e10403"
,ttl: "AutoCAD Installation and Licensing FAQs"
,ln: "./files/GUID-F9AC119F-40AB-4A91-9F55-D9F5D921EE61.htm"
,ic: 0
,children: [{
id: "d30e10421"
,ttl: "What are the additional products available for installation?"
,ln: "./files/GUID-AFB7BFBB-B202-4893-8434-A668D85EC2EF.htm"
,ic: 0
},
{
id: "d30e10444"
,ttl: "How can I be sure available service packs are included in my installation?"
,ln: "./files/GUID-D1660EB7-508C-4A5C-A2B7-61BE46D6C6A6.htm"
,ic: 0
},
{
id: "d30e10477"
,ttl: "How can I obtain local offline Help?"
,ln: "./files/GUID-4E2B453C-8F43-4F84-B95B-9ACA97E10568.htm"
,ic: 0
},
{
id: "d30e10512"
,ttl: "What features can I customize?"
,ln: "./files/GUID-849BA1C9-1360-475E-9F01-4F35DDE73330.htm"
,ic: 0
},
{
id: "d30e10628"
,ttl: "What are the tools and utilities available for installation?"
,ln: "./files/GUID-6B3E09EF-A0C3-4A61-9EFB-0FCCA2609341.htm"
,ic: 0
},
{
id: "d30e10676"
,ttl: "How can I migrate my custom settings and files from previous releases?"
,ln: "./files/GUID-EF95E1BB-8B83-40EE-9F44-23D57F1559E7.htm"
,ic: 0
},
{
id: "d30e10698"
,ttl: "What if I accidentally delete or alter required files? Can I replace or repair them?"
,ln: "./files/GUID-E55C0B78-A4F6-4C7A-91E8-23790CA40F3E.htm"
,ic: 0
},
{
id: "d30e10714"
,ttl: "How do I uninstall my software?"
,ln: "./files/GUID-38B516A1-117D-499F-BBC0-14F79699F543.htm"
,ic: 0
},
{
id: "d30e10743"
,ttl: "How do I use support content folders in a deployment?"
,ln: "./files/GUID-2E30D32C-48CC-45B9-900A-F7089F6DBB62.htm"
,ic: 0
},
{
id: "d30e10823"
,ttl: "What is the purpose of changing the default search paths and location of program files for a deployment?"
,ln: "./files/GUID-8F6F73C5-9155-4EB2-9DF3-0B71CBCDB125.htm"
,ic: 0
},
{
id: "d30e10841"
,ttl: "What is the purpose of configuring additional files in a deployment?"
,ln: "./files/GUID-28D0B39F-38EC-498F-86B4-5635D8EA007A.htm"
,ic: 0
},
{
id: "d30e10873"
,ttl: "How Can I Improve the Performance of My AutoCAD-based Product?"
,ln: "./files/GUID-7ACCD6D8-BCB2-477C-AB38-977A935F7C4D.htm"
,ic: 0
}
]}
]}
];
            var fileItems = [];
            
// SIG // Begin signature block
// SIG // MIIZNgYJKoZIhvcNAQcCoIIZJzCCGSMCAQExCzAJBgUr
// SIG // DgMCGgUAMGcGCisGAQQBgjcCAQSgWTBXMDIGCisGAQQB
// SIG // gjcCAR4wJAIBAQQQEODJBs441BGiowAQS9NQkAIBAAIB
// SIG // AAIBAAIBAAIBADAhMAkGBSsOAwIaBQAEFAvf1l6zakV5
// SIG // wDNmM8CNjsFxBibRoIIUMDCCA+4wggNXoAMCAQICEH6T
// SIG // 6/t8xk5Z6kuad9QG/DswDQYJKoZIhvcNAQEFBQAwgYsx
// SIG // CzAJBgNVBAYTAlpBMRUwEwYDVQQIEwxXZXN0ZXJuIENh
// SIG // cGUxFDASBgNVBAcTC0R1cmJhbnZpbGxlMQ8wDQYDVQQK
// SIG // EwZUaGF3dGUxHTAbBgNVBAsTFFRoYXd0ZSBDZXJ0aWZp
// SIG // Y2F0aW9uMR8wHQYDVQQDExZUaGF3dGUgVGltZXN0YW1w
// SIG // aW5nIENBMB4XDTEyMTIyMTAwMDAwMFoXDTIwMTIzMDIz
// SIG // NTk1OVowXjELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5
// SIG // bWFudGVjIENvcnBvcmF0aW9uMTAwLgYDVQQDEydTeW1h
// SIG // bnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIENBIC0g
// SIG // RzIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
// SIG // AQCxrLNJVEuXHBIK2CV5kSJXKm/cuCbEQ3Nrwr8uUFr7
// SIG // FMJ2jkMBJUO0oeJF9Oi3e8N0zCLXtJQAAvdN7b+0t0Qk
// SIG // a81fRTvRRM5DEnMXgotptCvLmR6schsmTXEfsTHd+1Fh
// SIG // AlOmqvVJLAV4RaUvic7nmef+jOJXPz3GktxK+Hsz5HkK
// SIG // +/B1iEGc/8UDUZmq12yfk2mHZSmDhcJgFMTIyTsU2sCB
// SIG // 8B8NdN6SIqvK9/t0fCfm90obf6fDni2uiuqm5qonFn1h
// SIG // 95hxEbziUKFL5V365Q6nLJ+qZSDT2JboyHylTkhE/xni
// SIG // RAeSC9dohIBdanhkRc1gRn5UwRN8xXnxycFxAgMBAAGj
// SIG // gfowgfcwHQYDVR0OBBYEFF+a9W5czMx0mtTdfe8/2+xM
// SIG // gC7dMDIGCCsGAQUFBwEBBCYwJDAiBggrBgEFBQcwAYYW
// SIG // aHR0cDovL29jc3AudGhhd3RlLmNvbTASBgNVHRMBAf8E
// SIG // CDAGAQH/AgEAMD8GA1UdHwQ4MDYwNKAyoDCGLmh0dHA6
// SIG // Ly9jcmwudGhhd3RlLmNvbS9UaGF3dGVUaW1lc3RhbXBp
// SIG // bmdDQS5jcmwwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDgYD
// SIG // VR0PAQH/BAQDAgEGMCgGA1UdEQQhMB+kHTAbMRkwFwYD
// SIG // VQQDExBUaW1lU3RhbXAtMjA0OC0xMA0GCSqGSIb3DQEB
// SIG // BQUAA4GBAAMJm495739ZMKrvaLX64wkdu0+CBl03X6ZS
// SIG // nxaN6hySCURu9W3rWHww6PlpjSNzCxJvR6muORH4KrGb
// SIG // sBrDjutZlgCtzgxNstAxpghcKnr84nodV0yoZRjpeUBi
// SIG // JZZux8c3aoMhCI5B6t3ZVz8dd0mHKhYGXqY4aiISo1EZ
// SIG // g362MIIEozCCA4ugAwIBAgIQDs/0OMj+vzVuBNhqmBsa
// SIG // UDANBgkqhkiG9w0BAQUFADBeMQswCQYDVQQGEwJVUzEd
// SIG // MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAu
// SIG // BgNVBAMTJ1N5bWFudGVjIFRpbWUgU3RhbXBpbmcgU2Vy
// SIG // dmljZXMgQ0EgLSBHMjAeFw0xMjEwMTgwMDAwMDBaFw0y
// SIG // MDEyMjkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMR0wGwYD
// SIG // VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjE0MDIGA1UE
// SIG // AxMrU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNl
// SIG // cyBTaWduZXIgLSBHNDCCASIwDQYJKoZIhvcNAQEBBQAD
// SIG // ggEPADCCAQoCggEBAKJjCzlEuLsjp0RJuw7/ofBhClOT
// SIG // sJjbrSwPSsVu/4Y8U1UPFc4EPyv9qZaW2b5heQtbyUyG
// SIG // duXgQ0sile7CK0PBn9hotI5AT+6FOLkRxSPyZFjwFTJv
// SIG // TlehroikAtcqHs1L4d1j1ReJMluwXplaqJ0oUA4X7pbb
// SIG // YTtFUR3PElYLkkf8q672Zj1HrHBy55LnX80QucSDZJQZ
// SIG // vSWA4ejSIqXQugJ6oXeTW2XD7hd0vEGGKtwITIySjJEt
// SIG // nndEH2jWqHR32w5bMotWizO92WPISZ06xcXqMwvS8aMb
// SIG // 9Iu+2bNXizveBKd6IrIkri7HcMW+ToMmCPsLvalPmQjh
// SIG // EChyqs0CAwEAAaOCAVcwggFTMAwGA1UdEwEB/wQCMAAw
// SIG // FgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/
// SIG // BAQDAgeAMHMGCCsGAQUFBwEBBGcwZTAqBggrBgEFBQcw
// SIG // AYYeaHR0cDovL3RzLW9jc3Aud3Muc3ltYW50ZWMuY29t
// SIG // MDcGCCsGAQUFBzAChitodHRwOi8vdHMtYWlhLndzLnN5
// SIG // bWFudGVjLmNvbS90c3MtY2EtZzIuY2VyMDwGA1UdHwQ1
// SIG // MDMwMaAvoC2GK2h0dHA6Ly90cy1jcmwud3Muc3ltYW50
// SIG // ZWMuY29tL3Rzcy1jYS1nMi5jcmwwKAYDVR0RBCEwH6Qd
// SIG // MBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0yMDQ4LTIwHQYD
// SIG // VR0OBBYEFEbGaaMOShQe1UzaUmMXP142vA3mMB8GA1Ud
// SIG // IwQYMBaAFF+a9W5czMx0mtTdfe8/2+xMgC7dMA0GCSqG
// SIG // SIb3DQEBBQUAA4IBAQB4O7SRKgBM8I9iMDd4o4QnB28Y
// SIG // st4l3KDUlAOqhk4ln5pAAxzdzuN5yyFoBtq2MrRtv/Qs
// SIG // JmMz5ElkbQ3mw2cO9wWkNWx8iRbG6bLfsundIMZxD82V
// SIG // dNy2XN69Nx9DeOZ4tc0oBCCjqvFLxIgpkQ6A0RH83Vx2
// SIG // bk9eDkVGQW4NsOo4mrE62glxEPwcebSAe6xp9P2ctgwW
// SIG // K/F/Wwk9m1viFsoTgW0ALjgNqCmPLOGy9FqpAa8VnCwv
// SIG // SRvbIrvD/niUUcOGsYKIXfA9tFGheTMrLnu53CAJE3Hr
// SIG // ahlbz+ilMFcsiUk/uc9/yb8+ImhjU5q9aXSsxR08f5Lg
// SIG // w7wc2AR1MIIFhTCCBG2gAwIBAgIQKcFbP6rNUmpOZ708
// SIG // Tn4/8jANBgkqhkiG9w0BAQUFADCBtDELMAkGA1UEBhMC
// SIG // VVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYD
// SIG // VQQLExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTswOQYD
// SIG // VQQLEzJUZXJtcyBvZiB1c2UgYXQgaHR0cHM6Ly93d3cu
// SIG // dmVyaXNpZ24uY29tL3JwYSAoYykxMDEuMCwGA1UEAxMl
// SIG // VmVyaVNpZ24gQ2xhc3MgMyBDb2RlIFNpZ25pbmcgMjAx
// SIG // MCBDQTAeFw0xMjA3MjUwMDAwMDBaFw0xNTA5MjAyMzU5
// SIG // NTlaMIHIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2Fs
// SIG // aWZvcm5pYTETMBEGA1UEBxMKU2FuIFJhZmFlbDEWMBQG
// SIG // A1UEChQNQXV0b2Rlc2ssIEluYzE+MDwGA1UECxM1RGln
// SIG // aXRhbCBJRCBDbGFzcyAzIC0gTWljcm9zb2Z0IFNvZnR3
// SIG // YXJlIFZhbGlkYXRpb24gdjIxHzAdBgNVBAsUFkRlc2ln
// SIG // biBTb2x1dGlvbnMgR3JvdXAxFjAUBgNVBAMUDUF1dG9k
// SIG // ZXNrLCBJbmMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// SIG // ggEKAoIBAQCoYmDrmd0Gq8ezSsDlfgaJFEFplNPNhWzM
// SIG // 2uFQaYAB/ggpQ11+N4B6ao+TqrNIWDIqt3JKhaU889nx
// SIG // l/7teWGwuOurstI2Z0bEDhXiXam/bicK2HVLyntliQ+6
// SIG // tT+nlgfN8tgB2NzM0BpE1YCnU2b6DwQw4V7BV+/F//83
// SIG // yGFOpePlumzXxNw9EKWkaq81slmmTxf7UxZgP9PGbLw8
// SIG // gLAPk4PTJI97+5BBqhkLb1YqSfWn3PNMfsNKhw/VwAN0
// SIG // dRKeM6H8SkOdz+osr+NyH86lsKQuics4fwK5uFSHQHsI
// SIG // t6Z0tqWvminRqceUi9ugRlGryh9X1ZqCqfL/ggdzYa3Z
// SIG // AgMBAAGjggF7MIIBdzAJBgNVHRMEAjAAMA4GA1UdDwEB
// SIG // /wQEAwIHgDBABgNVHR8EOTA3MDWgM6Axhi9odHRwOi8v
// SIG // Y3NjMy0yMDEwLWNybC52ZXJpc2lnbi5jb20vQ1NDMy0y
// SIG // MDEwLmNybDBEBgNVHSAEPTA7MDkGC2CGSAGG+EUBBxcD
// SIG // MCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LnZlcmlz
// SIG // aWduLmNvbS9ycGEwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
// SIG // cQYIKwYBBQUHAQEEZTBjMCQGCCsGAQUFBzABhhhodHRw
// SIG // Oi8vb2NzcC52ZXJpc2lnbi5jb20wOwYIKwYBBQUHMAKG
// SIG // L2h0dHA6Ly9jc2MzLTIwMTAtYWlhLnZlcmlzaWduLmNv
// SIG // bS9DU0MzLTIwMTAuY2VyMB8GA1UdIwQYMBaAFM+Zqep7
// SIG // JvRLyY6P1/AFJu/j0qedMBEGCWCGSAGG+EIBAQQEAwIE
// SIG // EDAWBgorBgEEAYI3AgEbBAgwBgEBAAEB/zANBgkqhkiG
// SIG // 9w0BAQUFAAOCAQEA2OkGvuiY7TyI6yVTQAYmTO+MpOFG
// SIG // C8MflHSbofJiuLxrS1KXbkzsAPFPPsU1ouftFhsXFtDQ
// SIG // 8rMTq/jwugTpbJUREV0buEkLl8AKRhYQTKBKg1I/puBv
// SIG // bkJocDE0pRwtBz3xSlXXEwyYPcbCOnrM3OZ5bKx1Qiii
// SIG // vixlcGWhO3ws904ssutPFf4mV5PDi3U2Yp1HgbBK/Um/
// SIG // FLr6YAYeZaA8KY1CfQEisF3UKTwm72d7S+fJf++SOGea
// SIG // K0kumehVcbavQJTOVebuZ9V+qU0nk1lMrqve9BnQK69B
// SIG // QqNZu77vCO0wm81cfynAxkOYKZG3idY47qPJOgXKkwmI
// SIG // 2+92ozCCBgowggTyoAMCAQICEFIA5aolVvwahu2WydRL
// SIG // M8cwDQYJKoZIhvcNAQEFBQAwgcoxCzAJBgNVBAYTAlVT
// SIG // MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UE
// SIG // CxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgGA1UE
// SIG // CxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBGb3Ig
// SIG // YXV0aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8VmVy
// SIG // aVNpZ24gQ2xhc3MgMyBQdWJsaWMgUHJpbWFyeSBDZXJ0
// SIG // aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MB4XDTEwMDIw
// SIG // ODAwMDAwMFoXDTIwMDIwNzIzNTk1OVowgbQxCzAJBgNV
// SIG // BAYTAlVTMRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEf
// SIG // MB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE7
// SIG // MDkGA1UECxMyVGVybXMgb2YgdXNlIGF0IGh0dHBzOi8v
// SIG // d3d3LnZlcmlzaWduLmNvbS9ycGEgKGMpMTAxLjAsBgNV
// SIG // BAMTJVZlcmlTaWduIENsYXNzIDMgQ29kZSBTaWduaW5n
// SIG // IDIwMTAgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// SIG // ggEKAoIBAQD1I0tepdeKuzLp1Ff37+THJn6tGZj+qJ19
// SIG // lPY2axDXdYEwfwRof8srdR7NHQiM32mUpzejnHuA4Jnh
// SIG // 7jdNX847FO6G1ND1JzW8JQs4p4xjnRejCKWrsPvNamKC
// SIG // TNUh2hvZ8eOEO4oqT4VbkAFPyad2EH8nA3y+rn59wd35
// SIG // BbwbSJxp58CkPDxBAD7fluXF5JRx1lUBxwAmSkA8taEm
// SIG // qQynbYCOkCV7z78/HOsvlvrlh3fGtVayejtUMFMb32I0
// SIG // /x7R9FqTKIXlTBdOflv9pJOZf9/N76R17+8V9kfn+Bly
// SIG // 2C40Gqa0p0x+vbtPDD1X8TDWpjaO1oB21xkupc1+NC2J
// SIG // AgMBAAGjggH+MIIB+jASBgNVHRMBAf8ECDAGAQH/AgEA
// SIG // MHAGA1UdIARpMGcwZQYLYIZIAYb4RQEHFwMwVjAoBggr
// SIG // BgEFBQcCARYcaHR0cHM6Ly93d3cudmVyaXNpZ24uY29t
// SIG // L2NwczAqBggrBgEFBQcCAjAeGhxodHRwczovL3d3dy52
// SIG // ZXJpc2lnbi5jb20vcnBhMA4GA1UdDwEB/wQEAwIBBjBt
// SIG // BggrBgEFBQcBDARhMF+hXaBbMFkwVzBVFglpbWFnZS9n
// SIG // aWYwITAfMAcGBSsOAwIaBBSP5dMahqyNjmvDz4Bq1EgY
// SIG // LHsZLjAlFiNodHRwOi8vbG9nby52ZXJpc2lnbi5jb20v
// SIG // dnNsb2dvLmdpZjA0BgNVHR8ELTArMCmgJ6AlhiNodHRw
// SIG // Oi8vY3JsLnZlcmlzaWduLmNvbS9wY2EzLWc1LmNybDA0
// SIG // BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAGGGGh0dHA6
// SIG // Ly9vY3NwLnZlcmlzaWduLmNvbTAdBgNVHSUEFjAUBggr
// SIG // BgEFBQcDAgYIKwYBBQUHAwMwKAYDVR0RBCEwH6QdMBsx
// SIG // GTAXBgNVBAMTEFZlcmlTaWduTVBLSS0yLTgwHQYDVR0O
// SIG // BBYEFM+Zqep7JvRLyY6P1/AFJu/j0qedMB8GA1UdIwQY
// SIG // MBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqGSIb3
// SIG // DQEBBQUAA4IBAQBWIuY0pMRhy0i5Aa1WqGQP2YyRxLvM
// SIG // DOWteqAif99HOEotbNF/cRp87HCpsfBP5A8MU/oVXv50
// SIG // mEkkhYEmHJEUR7BMY4y7oTTUxkXoDYUmcwPQqYxkbdxx
// SIG // kuZFBWAVWVE5/FgUa/7UpO15awgMQXLnNyIGCb4j6T9E
// SIG // mh7pYZ3MsZBc/D3SjaxCPWU21LQ9QCiPmxDPIybMSyDL
// SIG // kB9djEw0yjzY5TfWb6UgvTTrJtmuDefFmvehtCGRM2+G
// SIG // 6Fi7JXx0Dlj+dRtjP84xfJuPG5aexVN2hFucrZH6rO2T
// SIG // ul3IIVPCglNjrxINUIcRGz1UUpaKLJw9khoImgUux5Ol
// SIG // SJHTMYIEcjCCBG4CAQEwgckwgbQxCzAJBgNVBAYTAlVT
// SIG // MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UE
// SIG // CxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE7MDkGA1UE
// SIG // CxMyVGVybXMgb2YgdXNlIGF0IGh0dHBzOi8vd3d3LnZl
// SIG // cmlzaWduLmNvbS9ycGEgKGMpMTAxLjAsBgNVBAMTJVZl
// SIG // cmlTaWduIENsYXNzIDMgQ29kZSBTaWduaW5nIDIwMTAg
// SIG // Q0ECECnBWz+qzVJqTme9PE5+P/IwCQYFKw4DAhoFAKBw
// SIG // MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEM
// SIG // BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
// SIG // BgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBRO/UEfYAwi
// SIG // SdvHal3pMKv3a8t/FDANBgkqhkiG9w0BAQEFAASCAQBg
// SIG // HTcpTtbddoqyTGYH3yiW+OjtNkvwqN1nmyvt7dSYT1cv
// SIG // lE03KmCRZSVLWUS9BtexkMujTCG8YhI/vQv6+kz0fsbl
// SIG // 0eUF+Hum5LZPccqU67FnFhwn/2ArI2ePiCxPS3pBOAIZ
// SIG // EVSP3K47mSAOT7EnTvGfR5O3qDDYDr6lV2apqWcmz4kH
// SIG // jI9yFECcBLohYBuJTdnqlq0xeUVcBeelsRQfpTTJ+9Vl
// SIG // +vD/ENSfSrE9/c8bbN+uWxnng8CXRQQwoiLEQQTfFedW
// SIG // giBHQCi+SgV12NmIQj3CuACJshXW0qj9fShcDZMYDjpe
// SIG // yyYKZyz2XNqTdDxof8u4ZgjoTzQBMf5SoYICCzCCAgcG
// SIG // CSqGSIb3DQEJBjGCAfgwggH0AgEBMHIwXjELMAkGA1UE
// SIG // BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0
// SIG // aW9uMTAwLgYDVQQDEydTeW1hbnRlYyBUaW1lIFN0YW1w
// SIG // aW5nIFNlcnZpY2VzIENBIC0gRzICEA7P9DjI/r81bgTY
// SIG // apgbGlAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzEL
// SIG // BgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE0MDEx
// SIG // MzIxNDA1MVowIwYJKoZIhvcNAQkEMRYEFMR8KgsQGWnc
// SIG // kOVCJA7Wn9VXldBbMA0GCSqGSIb3DQEBAQUABIIBAEOP
// SIG // JGhyhtBW0teoCOZwUDKqBeTPTBHj4U6fE71dcrP723L4
// SIG // Vdd9Y9CGURiEu3BumrA5rv3X+VFYqXUc2tqEdXpFSDLU
// SIG // dDjJxgVIIG1oAbzfAb+PMioX6A01ZnLDZa/tnDv2LzlN
// SIG // /kYFrnh+0qwdSDKnjcole3T6PEkw+SyL5AQSIu9AxRMu
// SIG // 51kwyC6oo9UuB2QRKMRyN3MxfdLT3eYmWV31CmlqnDXK
// SIG // brACE7hrD4KXgJTHdmgqejHdbIrlKbZsEHD2/xpJujTZ
// SIG // yz6kNE5Y79XEzjDMKbYFy6usONHz/iwWSCrdJc9VlSh7
// SIG // wDQjYv+WinyTBzSvhSqfIh/mj3+iqfQ=
// SIG // End signature block
