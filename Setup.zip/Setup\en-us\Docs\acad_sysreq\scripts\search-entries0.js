top.HlpSys.search.data.registerSearchDataProvider("", function (q, r) {var c = 0;var m = 100;var f = SearchResultsProvider.mergeResult;var w = top.HlpSys.search.ui.showWarning;var p = top.HlpSys.search.ui.updateProgress;if (!r) {r = new Array();}if ("0".match(q)) {r = f(r,[[1,3,[48,98,146]],[0,6,[48,59,87,120,129,158]]]);c++;}; 
if ("1".match(q)) {r = f(r,[[1,3,[32,36,41]],[0,3,[32,36,41]]]);c++;}; 
if ("1024".match(q)) {r = f(r,[[1,2,[84,134]],[0,2,[73,146]]]);c++;}; 
if ("1050".match(q)) {r = f(r,[[1,1,[89]],[0,1,[78]]]);c++;}; 
if ("128".match(q)) {r = f(r,[[1,1,[140]],[0,1,[152]]]);c++;}; 
if ("1280".match(q)) {r = f(r,[[1,1,[132]],[0,1,[144]]]);c++;}; 
if ("1600".match(q)) {r = f(r,[[1,1,[87]],[0,1,[76]]]);c++;}; 
if ("2".match(q)) {r = f(r,[[1,1,[76]],[0,2,[65,128]]]);c++;}; 
if ("2015".match(q)) {r = f(r,[[1,100,[2]],[0,101,[2,185]]]);c++;}; 
if ("3".match(q)) {r = f(r,[[1,1,[145]],[0,5,[58,68,119,132,157]]]);c++;}; 
if ("32".match(q)) {r = f(r,[[0,100,[-5]]]);c++;}; 
if ("3D".match(q)) {r = f(r,[[1,1,[-118]],[0,2,[-111,-180]]]);c++;}; 
if ("4".match(q)) {r = f(r,[[1,2,[69,114]],[0,3,[53,103,115]]]);c++;}; 
if ("5".match(q)) {r = f(r,[[1,1,[115]],[0,1,[104]]]);c++;}; 
if ("6".match(q)) {r = f(r,[[1,2,[97,123]],[0,2,[86,135]]]);c++;}; 
if ("64".match(q)) {r = f(r,[[1,101,[-5,53]],[0,2,[168,186]]]);c++;}; 
if ("7".match(q)) {r = f(r,[[1,4,[14,18,22,26]],[0,4,[14,18,22,26]]]);c++;}; 
if ("768".match(q)) {r = f(r,[[1,1,[86]],[0,1,[75]]]);c++;}; 
if ("8".match(q)) {r = f(r,[[1,2,[79,120]]]);c++;}; 
if ("8/8".match(q)) {r = f(r,[[1,3,[31,35,40]],[0,3,[31,35,40]]]);c++;}; 
if ("9".match(q)) {r = f(r,[[1,1,[47]],[0,1,[47]]]);c++;}; 
if ("adapt".match(q)) {r = f(r,[[1,1,[139]],[0,1,[151]]]);c++;}; 
if ("Addition".match(q)) {r = f(r,[[1,1,[116]],[0,1,[105]]]);c++;}; 
if ("AMD".match(q)) {r = f(r,[[1,2,[51,56]],[0,3,[-54,-117,-124]]]);c++;}; 
if ("ar".match(q)) {r = f(r,[[0,2,[172,-174]]]);c++;}; 
if ("Athlon".match(q)) {r = f(r,[[1,1,[52]],[0,2,[55,118]]]);c++;}; 
if ("AutoCAD".match(q)) {r = f(r,[[1,100,[1]],[0,101,[1,-184]]]);c++;}; 
if ("avail".match(q)) {r = f(r,[[1,1,[128]],[0,1,[140]]]);c++;}; 
if ("bit".match(q)) {r = f(r,[[1,100,[6]],[0,102,[6,169,187]]]);c++;}; 
if ("Browser".match(q)) {r = f(r,[[1,1,[43]],[0,1,[43]]]);c++;}; 
if ("capabl".match(q)) {r = f(r,[[1,1,[150]],[0,1,[162]]]);c++;}; 
if ("card".match(q)) {r = f(r,[[1,1,[154]],[0,1,[166]]]);c++;}; 
if ("class".match(q)) {r = f(r,[[1,1,[152]],[0,1,[164]]]);c++;}; 
if ("cloud".match(q)) {r = f(r,[[0,2,[110,179]]]);c++;}; 
if ("Color".match(q)) {r = f(r,[[1,2,[93,136]],[0,1,[82]]]);c++;}; 
if ("color".match(q)) {r = f(r,[[0,1,[148]]]);c++;}; 
if ("compliant".match(q)) {r = f(r,[[1,1,[104]],[0,1,[93]]]);c++;}; 
if ("Core".match(q)) {r = f(r,[[0,2,[57,126]]]);c++;}; 
if ("dataset".match(q)) {r = f(r,[[0,2,[108,177]]]);c++;}; 
if ("Descript".match(q)) {r = f(r,[[1,1,[8]],[0,1,[8]]]);c++;}; 
if ("Devic".match(q)) {r = f(r,[[1,1,[101]]]);c++;}; 
if ("devic".match(q)) {r = f(r,[[0,1,[90]]]);c++;}; 
if ("Direct3D".match(q)) {r = f(r,[[1,1,[148]],[0,1,[160]]]);c++;}; 
if ("disk".match(q)) {r = f(r,[[1,1,[127]],[0,1,[139]]]);c++;}; 
if ("Disk".match(q)) {r = f(r,[[1,1,[94]],[0,1,[83]]]);c++;}; 
if ("Displai".match(q)) {r = f(r,[[1,1,[82]],[0,1,[71]]]);c++;}; 
if ("displai".match(q)) {r = f(r,[[1,1,[138]],[0,1,[150]]]);c++;}; 
if ("Download".match(q)) {r = f(r,[[1,1,[106]],[0,1,[95]]]);c++;}; 
if ("Dual".match(q)) {r = f(r,[[0,2,[56,125]]]);c++;}; 
if ("DVD".match(q)) {r = f(r,[[1,1,[-108]],[0,1,[-97]]]);c++;}; 
if ("EM64T".match(q)) {r = f(r,[[1,2,[64,71]]]);c++;}; 
if ("Enterpris".match(q)) {r = f(r,[[1,2,[15,42]],[0,2,[15,42]]]);c++;}; 
if ("Explorer".match(q)) {r = f(r,[[1,1,[45]],[0,1,[45]]]);c++;}; 
if ("framework".match(q)) {r = f(r,[[0,1,[99]]]);c++;}; 
if ("Framework".match(q)) {r = f(r,[[1,2,[110,112]],[0,1,[101]]]);c++;}; 
if ("free".match(q)) {r = f(r,[[1,1,[125]],[0,1,[137]]]);c++;}; 
if ("GB".match(q)) {r = f(r,[[1,5,[77,80,99,121,124]],[0,5,[66,69,88,133,136]]]);c++;}; 
if ("GHz".match(q)) {r = f(r,[[0,3,[60,121,130]]]);c++;}; 
if ("graphic".match(q)) {r = f(r,[[1,1,[153]],[0,1,[165]]]);c++;}; 
if ("greater".match(q)) {r = f(r,[[1,2,[-142,-147]],[0,4,[-122,-131,-154,-159]]]);c++;}; 
if ("hard".match(q)) {r = f(r,[[1,1,[126]],[0,1,[138]]]);c++;}; 
if ("higher".match(q)) {r = f(r,[[1,1,[-90]],[0,1,[-79]]]);c++;}; 
if ("Higher".match(q)) {r = f(r,[[0,1,[-61]]]);c++;}; 
if ("Home".match(q)) {r = f(r,[[1,1,[27]],[0,1,[27]]]);c++;}; 
if ("includ".match(q)) {r = f(r,[[1,1,[-129]],[0,1,[-141]]]);c++;}; 
if ("inform".match(q)) {r = f(r,[[0,1,[-190]]]);c++;}; 
if ("instal".match(q)) {r = f(r,[[1,1,[130]],[0,1,[142]]]);c++;}; 
if ("Installat".match(q)) {r = f(r,[[1,2,[96,-107]],[0,2,[85,-96]]]);c++;}; 
if ("Intel".match(q)) {r = f(r,[[1,4,[60,-63,67,-70]],[0,3,[51,113,-123]]]);c++;}; 
if ("Internet".match(q)) {r = f(r,[[1,1,[44]],[0,1,[44]]]);c++;}; 
if ("larg".match(q)) {r = f(r,[[0,2,[-107,-176]]]);c++;}; 
if ("later".match(q)) {r = f(r,[[1,1,[-49]],[0,1,[-49]]]);c++;}; 
if ("MB".match(q)) {r = f(r,[[1,1,[141]],[0,1,[153]]]);c++;}; 
if ("Media".match(q)) {r = f(r,[[1,1,[105]],[0,1,[94]]]);c++;}; 
if ("Memori".match(q)) {r = f(r,[[1,1,[75]],[0,1,[64]]]);c++;}; 
if ("Microsoft".match(q)) {r = f(r,[[1,7,[12,16,20,24,29,33,38]],[0,7,[12,16,20,24,29,33,38]]]);c++;}; 
if ("Model".match(q)) {r = f(r,[[1,1,[119]]]);c++;}; 
if ("model".match(q)) {r = f(r,[[0,2,[112,181]]]);c++;}; 
if ("Mous".match(q)) {r = f(r,[[1,1,[103]],[0,1,[92]]]);c++;}; 
if ("MS".match(q)) {r = f(r,[[1,1,[102]],[0,1,[91]]]);c++;}; 
if ("NET".match(q)) {r = f(r,[[1,2,[109,111]],[0,2,[98,100]]]);c++;}; 
if ("Note:".match(q)) {r = f(r,[[0,1,[167]]]);c++;}; 
if ("oper".match(q)) {r = f(r,[[0,1,[170]]]);c++;}; 
if ("Operat".match(q)) {r = f(r,[[1,1,[10]],[0,1,[10]]]);c++;}; 
if ("Opteron™".match(q)) {r = f(r,[[1,1,[57]]]);c++;}; 
if ("Pentium".match(q)) {r = f(r,[[1,1,[68]],[0,2,[52,114]]]);c++;}; 
if ("Pixel".match(q)) {r = f(r,[[1,1,[143]],[0,1,[155]]]);c++;}; 
if ("pleas".match(q)) {r = f(r,[[0,1,[182]]]);c++;}; 
if ("Point".match(q)) {r = f(r,[[1,1,[100]],[0,1,[89]]]);c++;}; 
if ("point".match(q)) {r = f(r,[[0,2,[109,178]]]);c++;}; 
if ("Premium".match(q)) {r = f(r,[[1,1,[28]],[0,1,[28]]]);c++;}; 
if ("Pro".match(q)) {r = f(r,[[1,1,[37]],[0,1,[37]]]);c++;}; 
if ("processor".match(q)) {r = f(r,[[0,2,[116,127]]]);c++;}; 
if ("Processor".match(q)) {r = f(r,[[1,1,[50]],[0,1,[50]]]);c++;}; 
if ("Profession".match(q)) {r = f(r,[[1,1,[23]],[0,1,[23]]]);c++;}; 
if ("RAM".match(q)) {r = f(r,[[1,2,[78,122]],[0,2,[67,134]]]);c++;}; 
if ("recommend".match(q)) {r = f(r,[[1,2,[81,91]],[0,2,[80,173]]]);c++;}; 
if ("Recommend".match(q)) {r = f(r,[[0,1,[70]]]);c++;}; 
if ("refer".match(q)) {r = f(r,[[0,1,[183]]]);c++;}; 
if ("Requir".match(q)) {r = f(r,[[1,101,[4,9]],[0,102,[4,9,189]]]);c++;}; 
if (c>m) {w('results.limit',false); return r}; 
if ("requir".match(q)) {r = f(r,[[1,2,[117,131]],[0,2,[106,143]]]);c++;}; 
if ("resolut".match(q)) {r = f(r,[[1,1,[83]],[0,1,[72]]]);c++;}; 
if ("Shader".match(q)) {r = f(r,[[1,1,[144]],[0,1,[156]]]);c++;}; 
if ("space".match(q)) {r = f(r,[[0,1,[84]]]);c++;}; 
if ("Space".match(q)) {r = f(r,[[1,1,[95]]]);c++;}; 
if ("SSE2".match(q)) {r = f(r,[[1,4,[-54,-58,-66,-73]],[0,1,[-62]]]);c++;}; 
if ("support".match(q)) {r = f(r,[[1,2,[65,72]]]);c++;}; 
if ("system".match(q)) {r = f(r,[[1,1,[11]],[0,2,[11,171]]]);c++;}; 
if ("System".match(q)) {r = f(r,[[1,100,[3]],[0,101,[3,188]]]);c++;}; 
if ("technolog".match(q)) {r = f(r,[[1,3,[55,59,74]],[0,1,[63]]]);c++;}; 
if ("True".match(q)) {r = f(r,[[1,2,[-92,135]],[0,2,[-81,147]]]);c++;}; 
if ("Ultimat".match(q)) {r = f(r,[[1,1,[19]],[0,1,[19]]]);c++;}; 
if ("Version".match(q)) {r = f(r,[[1,1,[113]],[0,1,[102]]]);c++;}; 
if ("video".match(q)) {r = f(r,[[1,1,[137]],[0,1,[149]]]);c++;}; 
if ("Window".match(q)) {r = f(r,[[1,7,[13,17,21,25,30,34,39]],[0,7,[13,17,21,25,30,34,39]]]);c++;}; 
if ("work".match(q)) {r = f(r,[[0,1,[175]]]);c++;}; 
if ("Workstat".match(q)) {r = f(r,[[0,100,[7]]]);c++;}; 
if ("workstat".match(q)) {r = f(r,[[1,101,[7,151]],[0,1,[163]]]);c++;}; 
if ("x".match(q)) {r = f(r,[[1,3,[85,88,133]],[0,3,[74,77,145]]]);c++;}; 
if ("Xeon".match(q)) {r = f(r,[[1,1,[61]]]);c++;}; 
if ("®".match(q)) {r = f(r,[[1,3,[46,62,149]],[0,2,[46,161]]]);c++;}; 
return r;});
// SIG // Begin signature block
// SIG // MIIZNgYJKoZIhvcNAQcCoIIZJzCCGSMCAQExCzAJBgUr
// SIG // DgMCGgUAMGcGCisGAQQBgjcCAQSgWTBXMDIGCisGAQQB
// SIG // gjcCAR4wJAIBAQQQEODJBs441BGiowAQS9NQkAIBAAIB
// SIG // AAIBAAIBAAIBADAhMAkGBSsOAwIaBQAEFB8ohq5hpUoN
// SIG // uADJrgxRuJWweVvYoIIUMDCCA+4wggNXoAMCAQICEH6T
// SIG // 6/t8xk5Z6kuad9QG/DswDQYJKoZIhvcNAQEFBQAwgYsx
// SIG // CzAJBgNVBAYTAlpBMRUwEwYDVQQIEwxXZXN0ZXJuIENh
// SIG // cGUxFDASBgNVBAcTC0R1cmJhbnZpbGxlMQ8wDQYDVQQK
// SIG // EwZUaGF3dGUxHTAbBgNVBAsTFFRoYXd0ZSBDZXJ0aWZp
// SIG // Y2F0aW9uMR8wHQYDVQQDExZUaGF3dGUgVGltZXN0YW1w
// SIG // aW5nIENBMB4XDTEyMTIyMTAwMDAwMFoXDTIwMTIzMDIz
// SIG // NTk1OVowXjELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5
// SIG // bWFudGVjIENvcnBvcmF0aW9uMTAwLgYDVQQDEydTeW1h
// SIG // bnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIENBIC0g
// SIG // RzIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
// SIG // AQCxrLNJVEuXHBIK2CV5kSJXKm/cuCbEQ3Nrwr8uUFr7
// SIG // FMJ2jkMBJUO0oeJF9Oi3e8N0zCLXtJQAAvdN7b+0t0Qk
// SIG // a81fRTvRRM5DEnMXgotptCvLmR6schsmTXEfsTHd+1Fh
// SIG // AlOmqvVJLAV4RaUvic7nmef+jOJXPz3GktxK+Hsz5HkK
// SIG // +/B1iEGc/8UDUZmq12yfk2mHZSmDhcJgFMTIyTsU2sCB
// SIG // 8B8NdN6SIqvK9/t0fCfm90obf6fDni2uiuqm5qonFn1h
// SIG // 95hxEbziUKFL5V365Q6nLJ+qZSDT2JboyHylTkhE/xni
// SIG // RAeSC9dohIBdanhkRc1gRn5UwRN8xXnxycFxAgMBAAGj
// SIG // gfowgfcwHQYDVR0OBBYEFF+a9W5czMx0mtTdfe8/2+xM
// SIG // gC7dMDIGCCsGAQUFBwEBBCYwJDAiBggrBgEFBQcwAYYW
// SIG // aHR0cDovL29jc3AudGhhd3RlLmNvbTASBgNVHRMBAf8E
// SIG // CDAGAQH/AgEAMD8GA1UdHwQ4MDYwNKAyoDCGLmh0dHA6
// SIG // Ly9jcmwudGhhd3RlLmNvbS9UaGF3dGVUaW1lc3RhbXBp
// SIG // bmdDQS5jcmwwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDgYD
// SIG // VR0PAQH/BAQDAgEGMCgGA1UdEQQhMB+kHTAbMRkwFwYD
// SIG // VQQDExBUaW1lU3RhbXAtMjA0OC0xMA0GCSqGSIb3DQEB
// SIG // BQUAA4GBAAMJm495739ZMKrvaLX64wkdu0+CBl03X6ZS
// SIG // nxaN6hySCURu9W3rWHww6PlpjSNzCxJvR6muORH4KrGb
// SIG // sBrDjutZlgCtzgxNstAxpghcKnr84nodV0yoZRjpeUBi
// SIG // JZZux8c3aoMhCI5B6t3ZVz8dd0mHKhYGXqY4aiISo1EZ
// SIG // g362MIIEozCCA4ugAwIBAgIQDs/0OMj+vzVuBNhqmBsa
// SIG // UDANBgkqhkiG9w0BAQUFADBeMQswCQYDVQQGEwJVUzEd
// SIG // MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAu
// SIG // BgNVBAMTJ1N5bWFudGVjIFRpbWUgU3RhbXBpbmcgU2Vy
// SIG // dmljZXMgQ0EgLSBHMjAeFw0xMjEwMTgwMDAwMDBaFw0y
// SIG // MDEyMjkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMR0wGwYD
// SIG // VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjE0MDIGA1UE
// SIG // AxMrU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNl
// SIG // cyBTaWduZXIgLSBHNDCCASIwDQYJKoZIhvcNAQEBBQAD
// SIG // ggEPADCCAQoCggEBAKJjCzlEuLsjp0RJuw7/ofBhClOT
// SIG // sJjbrSwPSsVu/4Y8U1UPFc4EPyv9qZaW2b5heQtbyUyG
// SIG // duXgQ0sile7CK0PBn9hotI5AT+6FOLkRxSPyZFjwFTJv
// SIG // TlehroikAtcqHs1L4d1j1ReJMluwXplaqJ0oUA4X7pbb
// SIG // YTtFUR3PElYLkkf8q672Zj1HrHBy55LnX80QucSDZJQZ
// SIG // vSWA4ejSIqXQugJ6oXeTW2XD7hd0vEGGKtwITIySjJEt
// SIG // nndEH2jWqHR32w5bMotWizO92WPISZ06xcXqMwvS8aMb
// SIG // 9Iu+2bNXizveBKd6IrIkri7HcMW+ToMmCPsLvalPmQjh
// SIG // EChyqs0CAwEAAaOCAVcwggFTMAwGA1UdEwEB/wQCMAAw
// SIG // FgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/
// SIG // BAQDAgeAMHMGCCsGAQUFBwEBBGcwZTAqBggrBgEFBQcw
// SIG // AYYeaHR0cDovL3RzLW9jc3Aud3Muc3ltYW50ZWMuY29t
// SIG // MDcGCCsGAQUFBzAChitodHRwOi8vdHMtYWlhLndzLnN5
// SIG // bWFudGVjLmNvbS90c3MtY2EtZzIuY2VyMDwGA1UdHwQ1
// SIG // MDMwMaAvoC2GK2h0dHA6Ly90cy1jcmwud3Muc3ltYW50
// SIG // ZWMuY29tL3Rzcy1jYS1nMi5jcmwwKAYDVR0RBCEwH6Qd
// SIG // MBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0yMDQ4LTIwHQYD
// SIG // VR0OBBYEFEbGaaMOShQe1UzaUmMXP142vA3mMB8GA1Ud
// SIG // IwQYMBaAFF+a9W5czMx0mtTdfe8/2+xMgC7dMA0GCSqG
// SIG // SIb3DQEBBQUAA4IBAQB4O7SRKgBM8I9iMDd4o4QnB28Y
// SIG // st4l3KDUlAOqhk4ln5pAAxzdzuN5yyFoBtq2MrRtv/Qs
// SIG // JmMz5ElkbQ3mw2cO9wWkNWx8iRbG6bLfsundIMZxD82V
// SIG // dNy2XN69Nx9DeOZ4tc0oBCCjqvFLxIgpkQ6A0RH83Vx2
// SIG // bk9eDkVGQW4NsOo4mrE62glxEPwcebSAe6xp9P2ctgwW
// SIG // K/F/Wwk9m1viFsoTgW0ALjgNqCmPLOGy9FqpAa8VnCwv
// SIG // SRvbIrvD/niUUcOGsYKIXfA9tFGheTMrLnu53CAJE3Hr
// SIG // ahlbz+ilMFcsiUk/uc9/yb8+ImhjU5q9aXSsxR08f5Lg
// SIG // w7wc2AR1MIIFhTCCBG2gAwIBAgIQKcFbP6rNUmpOZ708
// SIG // Tn4/8jANBgkqhkiG9w0BAQUFADCBtDELMAkGA1UEBhMC
// SIG // VVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYD
// SIG // VQQLExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTswOQYD
// SIG // VQQLEzJUZXJtcyBvZiB1c2UgYXQgaHR0cHM6Ly93d3cu
// SIG // dmVyaXNpZ24uY29tL3JwYSAoYykxMDEuMCwGA1UEAxMl
// SIG // VmVyaVNpZ24gQ2xhc3MgMyBDb2RlIFNpZ25pbmcgMjAx
// SIG // MCBDQTAeFw0xMjA3MjUwMDAwMDBaFw0xNTA5MjAyMzU5
// SIG // NTlaMIHIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2Fs
// SIG // aWZvcm5pYTETMBEGA1UEBxMKU2FuIFJhZmFlbDEWMBQG
// SIG // A1UEChQNQXV0b2Rlc2ssIEluYzE+MDwGA1UECxM1RGln
// SIG // aXRhbCBJRCBDbGFzcyAzIC0gTWljcm9zb2Z0IFNvZnR3
// SIG // YXJlIFZhbGlkYXRpb24gdjIxHzAdBgNVBAsUFkRlc2ln
// SIG // biBTb2x1dGlvbnMgR3JvdXAxFjAUBgNVBAMUDUF1dG9k
// SIG // ZXNrLCBJbmMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// SIG // ggEKAoIBAQCoYmDrmd0Gq8ezSsDlfgaJFEFplNPNhWzM
// SIG // 2uFQaYAB/ggpQ11+N4B6ao+TqrNIWDIqt3JKhaU889nx
// SIG // l/7teWGwuOurstI2Z0bEDhXiXam/bicK2HVLyntliQ+6
// SIG // tT+nlgfN8tgB2NzM0BpE1YCnU2b6DwQw4V7BV+/F//83
// SIG // yGFOpePlumzXxNw9EKWkaq81slmmTxf7UxZgP9PGbLw8
// SIG // gLAPk4PTJI97+5BBqhkLb1YqSfWn3PNMfsNKhw/VwAN0
// SIG // dRKeM6H8SkOdz+osr+NyH86lsKQuics4fwK5uFSHQHsI
// SIG // t6Z0tqWvminRqceUi9ugRlGryh9X1ZqCqfL/ggdzYa3Z
// SIG // AgMBAAGjggF7MIIBdzAJBgNVHRMEAjAAMA4GA1UdDwEB
// SIG // /wQEAwIHgDBABgNVHR8EOTA3MDWgM6Axhi9odHRwOi8v
// SIG // Y3NjMy0yMDEwLWNybC52ZXJpc2lnbi5jb20vQ1NDMy0y
// SIG // MDEwLmNybDBEBgNVHSAEPTA7MDkGC2CGSAGG+EUBBxcD
// SIG // MCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LnZlcmlz
// SIG // aWduLmNvbS9ycGEwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
// SIG // cQYIKwYBBQUHAQEEZTBjMCQGCCsGAQUFBzABhhhodHRw
// SIG // Oi8vb2NzcC52ZXJpc2lnbi5jb20wOwYIKwYBBQUHMAKG
// SIG // L2h0dHA6Ly9jc2MzLTIwMTAtYWlhLnZlcmlzaWduLmNv
// SIG // bS9DU0MzLTIwMTAuY2VyMB8GA1UdIwQYMBaAFM+Zqep7
// SIG // JvRLyY6P1/AFJu/j0qedMBEGCWCGSAGG+EIBAQQEAwIE
// SIG // EDAWBgorBgEEAYI3AgEbBAgwBgEBAAEB/zANBgkqhkiG
// SIG // 9w0BAQUFAAOCAQEA2OkGvuiY7TyI6yVTQAYmTO+MpOFG
// SIG // C8MflHSbofJiuLxrS1KXbkzsAPFPPsU1ouftFhsXFtDQ
// SIG // 8rMTq/jwugTpbJUREV0buEkLl8AKRhYQTKBKg1I/puBv
// SIG // bkJocDE0pRwtBz3xSlXXEwyYPcbCOnrM3OZ5bKx1Qiii
// SIG // vixlcGWhO3ws904ssutPFf4mV5PDi3U2Yp1HgbBK/Um/
// SIG // FLr6YAYeZaA8KY1CfQEisF3UKTwm72d7S+fJf++SOGea
// SIG // K0kumehVcbavQJTOVebuZ9V+qU0nk1lMrqve9BnQK69B
// SIG // QqNZu77vCO0wm81cfynAxkOYKZG3idY47qPJOgXKkwmI
// SIG // 2+92ozCCBgowggTyoAMCAQICEFIA5aolVvwahu2WydRL
// SIG // M8cwDQYJKoZIhvcNAQEFBQAwgcoxCzAJBgNVBAYTAlVT
// SIG // MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UE
// SIG // CxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgGA1UE
// SIG // CxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBGb3Ig
// SIG // YXV0aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8VmVy
// SIG // aVNpZ24gQ2xhc3MgMyBQdWJsaWMgUHJpbWFyeSBDZXJ0
// SIG // aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MB4XDTEwMDIw
// SIG // ODAwMDAwMFoXDTIwMDIwNzIzNTk1OVowgbQxCzAJBgNV
// SIG // BAYTAlVTMRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEf
// SIG // MB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE7
// SIG // MDkGA1UECxMyVGVybXMgb2YgdXNlIGF0IGh0dHBzOi8v
// SIG // d3d3LnZlcmlzaWduLmNvbS9ycGEgKGMpMTAxLjAsBgNV
// SIG // BAMTJVZlcmlTaWduIENsYXNzIDMgQ29kZSBTaWduaW5n
// SIG // IDIwMTAgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// SIG // ggEKAoIBAQD1I0tepdeKuzLp1Ff37+THJn6tGZj+qJ19
// SIG // lPY2axDXdYEwfwRof8srdR7NHQiM32mUpzejnHuA4Jnh
// SIG // 7jdNX847FO6G1ND1JzW8JQs4p4xjnRejCKWrsPvNamKC
// SIG // TNUh2hvZ8eOEO4oqT4VbkAFPyad2EH8nA3y+rn59wd35
// SIG // BbwbSJxp58CkPDxBAD7fluXF5JRx1lUBxwAmSkA8taEm
// SIG // qQynbYCOkCV7z78/HOsvlvrlh3fGtVayejtUMFMb32I0
// SIG // /x7R9FqTKIXlTBdOflv9pJOZf9/N76R17+8V9kfn+Bly
// SIG // 2C40Gqa0p0x+vbtPDD1X8TDWpjaO1oB21xkupc1+NC2J
// SIG // AgMBAAGjggH+MIIB+jASBgNVHRMBAf8ECDAGAQH/AgEA
// SIG // MHAGA1UdIARpMGcwZQYLYIZIAYb4RQEHFwMwVjAoBggr
// SIG // BgEFBQcCARYcaHR0cHM6Ly93d3cudmVyaXNpZ24uY29t
// SIG // L2NwczAqBggrBgEFBQcCAjAeGhxodHRwczovL3d3dy52
// SIG // ZXJpc2lnbi5jb20vcnBhMA4GA1UdDwEB/wQEAwIBBjBt
// SIG // BggrBgEFBQcBDARhMF+hXaBbMFkwVzBVFglpbWFnZS9n
// SIG // aWYwITAfMAcGBSsOAwIaBBSP5dMahqyNjmvDz4Bq1EgY
// SIG // LHsZLjAlFiNodHRwOi8vbG9nby52ZXJpc2lnbi5jb20v
// SIG // dnNsb2dvLmdpZjA0BgNVHR8ELTArMCmgJ6AlhiNodHRw
// SIG // Oi8vY3JsLnZlcmlzaWduLmNvbS9wY2EzLWc1LmNybDA0
// SIG // BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAGGGGh0dHA6
// SIG // Ly9vY3NwLnZlcmlzaWduLmNvbTAdBgNVHSUEFjAUBggr
// SIG // BgEFBQcDAgYIKwYBBQUHAwMwKAYDVR0RBCEwH6QdMBsx
// SIG // GTAXBgNVBAMTEFZlcmlTaWduTVBLSS0yLTgwHQYDVR0O
// SIG // BBYEFM+Zqep7JvRLyY6P1/AFJu/j0qedMB8GA1UdIwQY
// SIG // MBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqGSIb3
// SIG // DQEBBQUAA4IBAQBWIuY0pMRhy0i5Aa1WqGQP2YyRxLvM
// SIG // DOWteqAif99HOEotbNF/cRp87HCpsfBP5A8MU/oVXv50
// SIG // mEkkhYEmHJEUR7BMY4y7oTTUxkXoDYUmcwPQqYxkbdxx
// SIG // kuZFBWAVWVE5/FgUa/7UpO15awgMQXLnNyIGCb4j6T9E
// SIG // mh7pYZ3MsZBc/D3SjaxCPWU21LQ9QCiPmxDPIybMSyDL
// SIG // kB9djEw0yjzY5TfWb6UgvTTrJtmuDefFmvehtCGRM2+G
// SIG // 6Fi7JXx0Dlj+dRtjP84xfJuPG5aexVN2hFucrZH6rO2T
// SIG // ul3IIVPCglNjrxINUIcRGz1UUpaKLJw9khoImgUux5Ol
// SIG // SJHTMYIEcjCCBG4CAQEwgckwgbQxCzAJBgNVBAYTAlVT
// SIG // MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UE
// SIG // CxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE7MDkGA1UE
// SIG // CxMyVGVybXMgb2YgdXNlIGF0IGh0dHBzOi8vd3d3LnZl
// SIG // cmlzaWduLmNvbS9ycGEgKGMpMTAxLjAsBgNVBAMTJVZl
// SIG // cmlTaWduIENsYXNzIDMgQ29kZSBTaWduaW5nIDIwMTAg
// SIG // Q0ECECnBWz+qzVJqTme9PE5+P/IwCQYFKw4DAhoFAKBw
// SIG // MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEM
// SIG // BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
// SIG // BgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBSgQhqvIYsX
// SIG // /xuaZnWKfZ0wfd3kXzANBgkqhkiG9w0BAQEFAASCAQAo
// SIG // NcVIbW1ylNAEgMfjA4HD+VnE3v67SNd1u/45FkKwmuUF
// SIG // zbPVCZn1yN1mNXqIXsLWKw4zkIzQ2hmHuMSAxzYo92D3
// SIG // 1gMqrORNdf+xq1eRNkR+C+5dnjp56Yrmzxp+W85VIMt6
// SIG // +OAt9AJxE75mVk5/MpxajnA8xChZiQfR7N1UYFhbApSP
// SIG // cvoWfiwfyaIf9uLz2Yieub5vx16AvRB9s4bcZgY53DmR
// SIG // qPwMDtR9cN7lIMgu5zuVQ0Ub6MajMZUXfq9wCw48W4B7
// SIG // f2cij8mHuzlSuL9UiGjoxrdHlnwveA7/rzahjpYYeX6S
// SIG // +/RHMo1GQ+BQXOKBxTTXUYOltFGsvwqeoYICCzCCAgcG
// SIG // CSqGSIb3DQEJBjGCAfgwggH0AgEBMHIwXjELMAkGA1UE
// SIG // BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0
// SIG // aW9uMTAwLgYDVQQDEydTeW1hbnRlYyBUaW1lIFN0YW1w
// SIG // aW5nIFNlcnZpY2VzIENBIC0gRzICEA7P9DjI/r81bgTY
// SIG // apgbGlAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzEL
// SIG // BgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTEzMTEx
// SIG // OTE4MDkwNVowIwYJKoZIhvcNAQkEMRYEFOixjdx/0gLB
// SIG // cKOqI/R5QF9lqGDJMA0GCSqGSIb3DQEBAQUABIIBAEqs
// SIG // 2LGnF0IB5tyjDOeS0rgw0YxNPQQTQCcXKl9i/KcAc4uq
// SIG // 4DONIic1gpAkpialARb1ty7I8FJvu6kcuPo/Y+zKuEDA
// SIG // cUEPtpmFCMyeQPZg2M9/vZX7RzZrjicubQMq/IHI4aqg
// SIG // zux4DelfjPBa2AKFCwzg3/bLp0+qfHowkfN6nK+qcbP/
// SIG // 9+LGwxSzgLvq+6VXlkLcRvXfubBsFGnqn0+UK0chnQfF
// SIG // lPZ0OZKjDNXvB+G8/r1BNDgyc3PprfoCHmb6F9yKbwnL
// SIG // vND/qEcRp8fTC74g7lg6iUuHcPqakIl1ALlzVjZ4jWYv
// SIG // 3/y+MoBYcgLrTxymDZaz1+thKg+ClCw=
// SIG // End signature block
